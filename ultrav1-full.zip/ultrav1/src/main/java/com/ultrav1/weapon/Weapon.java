package com.ultrav1.weapon;

import net.minecraft.core.particles.DustParticleOptions;
import org.joml.Vector3f;

/** The 15 ULTRAKILL weapon variants: 5 base weapons x blue / green / red. */
public enum Weapon {
    PIERCER("piercer", Family.REVOLVER, 0),
    MARKSMAN("marksman", Family.REVOLVER, 1),
    SHARPSHOOTER("sharpshooter", Family.REVOLVER, 2),

    CORE_EJECT("core_eject", Family.SHOTGUN, 0),
    PUMP_CHARGE("pump_charge", Family.SHOTGUN, 1),
    SAWED_ON("sawed_on", Family.SHOTGUN, 2),

    ATTRACTOR("attractor", Family.NAILGUN, 0),
    OVERHEAT("overheat", Family.NAILGUN, 1),
    JUMPSTART("jumpstart", Family.NAILGUN, 2),

    ELECTRIC("electric", Family.RAILCANNON, 0),
    SCREWDRIVER("screwdriver", Family.RAILCANNON, 1),
    MALICIOUS("malicious", Family.RAILCANNON, 2),

    FREEZEFRAME("freezeframe", Family.ROCKET, 0),
    SRS("srs_cannon", Family.ROCKET, 1),
    FIRESTARTER("firestarter", Family.ROCKET, 2);

    public enum Family { REVOLVER, SHOTGUN, NAILGUN, RAILCANNON, ROCKET }

    private static final float[][] TINT = {
            {0.25f, 0.65f, 1.0f},   // blue
            {0.25f, 0.9f, 0.35f},   // green
            {1.0f, 0.2f, 0.2f}      // red
    };

    public final String id;
    public final Family family;
    public final int color; // 0 blue, 1 green, 2 red

    Weapon(String id, Family family, int color) {
        this.id = id;
        this.family = family;
        this.color = color;
    }

    public DustParticleOptions dust() {
        float[] t = TINT[color];
        return new DustParticleOptions(new Vector3f(t[0], t[1], t[2]), 1.0f);
    }
}
