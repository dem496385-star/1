package com.ultrav1.weapon;

import com.ultrav1.UltraV1;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, UltraV1.MODID);
    private static final Map<Weapon, RegistryObject<Item>> WEAPONS = new EnumMap<>(Weapon.class);

    static {
        for (Weapon w : Weapon.values()) {
            WEAPONS.put(w, ITEMS.register(w.id, () -> new V1WeaponItem(new Item.Properties().stacksTo(1), w)));
        }
    }

    public static Item get(Weapon w) {
        return WEAPONS.get(w).get();
    }

    private ModItems() {}
}
