package com.ultrav1.weapon;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class V1WeaponItem extends Item {
    public final Weapon weapon;

    public V1WeaponItem(Properties props, Weapon weapon) {
        super(props);
        this.weapon = weapon;
    }

    /** Left click fires the gun, it must not break blocks. */
    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        return false;
    }
}
