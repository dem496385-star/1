package com.ultrav1.client;

import com.ultrav1.UltraV1;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * HUD as a single text line (the action-bar slot above the hotbar):
 * dash charges, style meter and the latest status from the server.
 * (Forge 1.21.1 has no HUD render event, so this uses the vanilla overlay message.)
 */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1Hud {
    private static String status = "";
    private static int statusTtl;

    public static void onStatus(String text) {
        status = text;
        statusTtl = 50;
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (statusTtl > 0) statusTtl--;

        MutableComponent c = Component.literal("DASH ").withStyle(ChatFormatting.GRAY);
        c.append(Component.literal("["));
        for (int i = 0; i < 3; i++) {
            float f = Math.max(0f, Math.min(1f, V1Movement.stamina - i));
            if (f >= 1f) c.append(Component.literal("#").withStyle(ChatFormatting.AQUA));
            else if (f > 0.5f) c.append(Component.literal("=").withStyle(ChatFormatting.DARK_AQUA));
            else c.append(Component.literal("-").withStyle(ChatFormatting.DARK_GRAY));
        }
        c.append(Component.literal("]"));

        Component style = V1StyleHud.component();
        if (style != null) {
            c.append(Component.literal("   "));
            c.append(style);
        }
        if (statusTtl > 0) {
            c.append(Component.literal("   " + status).withStyle(ChatFormatting.WHITE));
        }
        mc.gui.setOverlayMessage(c, false);
    }
}
