package com.ultrav1.client;

import com.ultrav1.UltraV1;
import com.ultrav1.network.SlamPacket;
import com.ultrav1.network.V1Network;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * V1 movement: dash (3 charges), slide, ground slam, wall jump (3 per airtime)
 * and SLAM STORAGE: wall jump while slamming keeps the slam charged until you land.
 * After landing you have a short window:
 *   slide key         -> launch forward
 *   jump              -> launch very high
 *   slide + jump      -> launch in an arc (forward + up)
 */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1Movement {
    public static final float MAX_STAMINA = 3f;
    public static float stamina = MAX_STAMINA;

    // ---- tuning ----
    private static final float DASH_COST = 1f;
    private static final float REGEN_PER_TICK = 0.4f / 20f;
    private static final double DASH_SPEED = 1.5;
    private static final int DASH_TICKS = 5;
    private static final double SLIDE_SPEED = 0.8;
    private static final double SLAM_SPEED = 1.5;      // half of the old speed
    private static final double STORAGE_POWER = 2.0;   // slam storage launch strength multiplier
    private static final int MAX_WALL_JUMPS = 3;
    private static final int STORAGE_WINDOW = 8;   // ticks after landing to press slide / jump
    private static final int COMBO_GRACE = 2;      // ticks to catch slide+jump pressed "together"

    // ---- state ----
    private static int dashTicks;
    private static Vec3 dashDir = Vec3.ZERO;
    private static boolean sliding, slamming, jumpWas, slideWas;
    private static Vec3 slideDir = Vec3.ZERO;
    private static double slideSpeed;
    private static double slamStartY;
    private static int wallJumps;

    private static boolean storedSlam;
    private static int window = 0, resolveIn = -1;
    private static float windowH;
    private static boolean pressedSlide, pressedJump;

    private static int boostTicks;
    private static Vec3 boostDir = Vec3.ZERO;
    private static double boostSpeed;

    public static boolean isDashing() { return dashTicks > 0; }
    public static boolean isSliding() { return sliding; }
    public static boolean isSlamming() { return slamming; }
    public static boolean isSlamStored() { return storedSlam || window > 0; }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) { reset(); return; }
        if (mc.screen != null || mc.isPaused()) return;
        if (V1WhipClient.isReeling()) { jumpWas = mc.options.keyJump.isDown(); return; }

        boolean onGround = p.onGround();
        boolean jumpDown = mc.options.keyJump.isDown();
        boolean jumpPress = jumpDown && !jumpWas;
        jumpWas = jumpDown;

        // Fresh press of the slide key (edge). Holding Ctrl while falling is NOT a slam.
        boolean slideDown = V1Keys.SLIDE.isDown();
        boolean slidePress = slideDown && !slideWas;
        slideWas = slideDown;
        while (V1Keys.SLIDE.consumeClick()) { /* drop queued clicks so they cannot fire later */ }

        if (onGround) wallJumps = 0;
        if (dashTicks == 0) stamina = Math.min(MAX_STAMINA, stamina + REGEN_PER_TICK);

        // ---- DASH ----
        while (V1Keys.DASH.consumeClick()) {
            if (stamina >= DASH_COST && dashTicks == 0) {
                stamina -= DASH_COST;
                dashDir = inputDirection(p);
                dashTicks = DASH_TICKS;
                V1Effects.onDash(p);
                slamming = false;
                sliding = false;
                boostTicks = 0;
                p.playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.4f);
            }
        }
        if (dashTicks > 0) {
            p.setDeltaMovement(dashDir.x * DASH_SPEED, 0, dashDir.z * DASH_SPEED);
            p.fallDistance = 0;
            dashTicks--;
            return;
        }

        // ---- LAUNCH BOOST (forward / arc after slam storage) ----
        if (boostTicks > 0) {
            if (p.horizontalCollision) {
                boostTicks = 0;
            } else {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(boostDir.x * boostSpeed, v.y, boostDir.z * boostSpeed);
                boostSpeed *= 0.975;
                boostTicks--;
            }
        }

        // ---- LANDING WITH STORED SLAM ----
        if (storedSlam && (onGround || p.isInWater() || p.getAbilities().flying)) {
            float h = (float) Math.max(0, slamStartY - p.getY());
            V1Network.CHANNEL.send(new SlamPacket(true, h), PacketDistributor.SERVER.noArg());
            storedSlam = false;
            V1Effects.onSlamImpact(p, h);
            if (onGround) {
                window = STORAGE_WINDOW;
                windowH = h;
                resolveIn = -1;
                pressedSlide = pressedJump = false;
            }
        }

        // ---- STORAGE WINDOW: slide / jump / both ----
        if (window > 0) {
            if (slidePress) pressedSlide = true;
            if (jumpPress) pressedJump = true;
            if ((pressedSlide || pressedJump) && resolveIn < 0) resolveIn = COMBO_GRACE;

            if (resolveIn >= 0) {
                if (resolveIn == 0) {
                    launch(p);
                    window = 0;
                    resolveIn = -1;
                } else {
                    resolveIn--;
                }
            } else {
                window--;
            }
            return; // no slide/wall logic during the window
        }

        // ---- SLAM (slide key in the air) ----
        if (!onGround && !slamming && slidePress) {
            slamming = true;
            sliding = false;
            boostTicks = 0;
            slamStartY = storedSlam ? Math.max(slamStartY, p.getY()) : p.getY();
            V1Network.CHANNEL.send(new SlamPacket(false, 0f), PacketDistributor.SERVER.noArg());
            V1Effects.onSlamStart(p);
        }
        if (slamming) {
            if (onGround) {
                float fall = (float) Math.max(0, slamStartY - p.getY());
                V1Network.CHANNEL.send(new SlamPacket(true, fall), PacketDistributor.SERVER.noArg());
                slamming = false;
                storedSlam = false;
                V1Effects.onSlamImpact(p, fall);
            } else {
                // wall jump while slamming = SLAM STORAGE
                if (jumpPress && wallJumps < MAX_WALL_JUMPS) {
                    Vec3 n = wallNormal(p);
                    if (n != null) {
                        doWallJump(p, n);
                        slamming = false;
                        storedSlam = true;
                        return;
                    }
                }
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x * 0.5, -SLAM_SPEED, v.z * 0.5);
                p.fallDistance = 0;
                return;
            }
        }

        // ---- SLIDE (slide key on the ground) ----
        if (onGround && slideDown && boostTicks == 0) {
            if (!sliding) {
                sliding = true;
                slideDir = inputDirection(p);
                slideSpeed = SLIDE_SPEED;
            }
            Vec3 v = p.getDeltaMovement();
            p.setDeltaMovement(slideDir.x * slideSpeed, v.y, slideDir.z * slideSpeed);
            slideSpeed = Math.max(0.3, slideSpeed * 0.985);
        } else {
            sliding = false;
        }

        // ---- WALL JUMP ----
        if (jumpPress && !onGround && wallJumps < MAX_WALL_JUMPS
                && !p.isInWater() && !p.isInLava() && !p.getAbilities().flying) {
            Vec3 n = wallNormal(p);
            if (n != null) doWallJump(p, n);
        }
    }

    private static void doWallJump(LocalPlayer p, Vec3 n) {
        wallJumps++;
        boostTicks = 0;
        p.setDeltaMovement(n.x * 0.45, 0.8, n.z * 0.45);
        p.fallDistance = 0;
        p.playSound(SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.6f, 1.6f);
        V1Effects.onWallJump(p, n);
    }

    /** Resolve the slam-storage launch from what was pressed in the window. */
    private static void launch(LocalPlayer p) {
        double h = Mth.clamp(windowH, 4f, 40f);
        Vec3 dir = inputDirection(p);
        p.fallDistance = 0;
        sliding = false;

        if (pressedSlide && pressedJump) {            // arc
            double speed = Math.min(0.9 + 0.015 * h, 1.8) * STORAGE_POWER;
            double up = Math.min(0.8 + 0.02 * h, 1.8) * STORAGE_POWER;
            p.setDeltaMovement(dir.x * speed, up, dir.z * speed);
            boostDir = dir; boostSpeed = speed; boostTicks = 25;
        } else if (pressedSlide) {                    // forward
            double speed = Math.min(1.2 + 0.02 * h, 2.4) * STORAGE_POWER;
            p.setDeltaMovement(dir.x * speed, 0.1, dir.z * speed);
            boostDir = dir; boostSpeed = speed; boostTicks = 30;
        } else {                                      // straight up
            double up = Math.min(1.0 + 0.03 * h, 3.0) * STORAGE_POWER;
            Vec3 v = p.getDeltaMovement();
            p.setDeltaMovement(v.x * 0.3, up, v.z * 0.3);
        }
        p.playSound(SoundEvents.ANVIL_LAND, 0.5f, 1.8f);
        V1Effects.onLaunch(p, (float) h);
        pressedSlide = pressedJump = false;
    }

    private static Vec3 inputDirection(LocalPlayer p) {
        float yaw = p.getYRot() * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        Vec3 left = new Vec3(Mth.cos(yaw), 0, Mth.sin(yaw));
        Vec3 d = fwd.scale(p.input.forwardImpulse).add(left.scale(p.input.leftImpulse));
        return d.lengthSqr() < 1.0E-4 ? fwd : d.normalize();
    }

    /** Horizontal direction pointing away from nearby walls, or null if no wall is touching. */
    private static Vec3 wallNormal(LocalPlayer p) {
        AABB bb = p.getBoundingBox();
        double x = 0, z = 0;
        if (!p.level().noCollision(p, bb.move(0.12, 0, 0))) x -= 1;
        if (!p.level().noCollision(p, bb.move(-0.12, 0, 0))) x += 1;
        if (!p.level().noCollision(p, bb.move(0, 0, 0.12))) z -= 1;
        if (!p.level().noCollision(p, bb.move(0, 0, -0.12))) z += 1;
        if (x == 0 && z == 0) return null;
        return new Vec3(x, 0, z).normalize();
    }

    private static void reset() {
        stamina = MAX_STAMINA;
        dashTicks = boostTicks = window = 0;
        resolveIn = -1;
        sliding = slamming = jumpWas = slideWas = storedSlam = pressedSlide = pressedJump = false;
        wallJumps = 0;
    }
}
