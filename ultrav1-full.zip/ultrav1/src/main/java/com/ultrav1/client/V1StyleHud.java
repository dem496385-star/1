package com.ultrav1.client;

import com.ultrav1.UltraV1;
import com.ultrav1.server.Style;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Style meter state. The text is drawn by V1Hud. */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1StyleHud {
    private static final String[] LETTERS = {"D", "C", "B", "A", "S", "SS", "SSS", "U"};
    private static final String[] NAMES = {"DESTRUCTIVE", "CHAOTIC", "BRUTAL", "ANARCHIC", "SUPREME",
            "SSADISTIC", "SSSHITSTORM", "ULTRAKILL"};
    private static final ChatFormatting[] COLORS = {ChatFormatting.GRAY, ChatFormatting.WHITE, ChatFormatting.YELLOW,
            ChatFormatting.GOLD, ChatFormatting.RED, ChatFormatting.DARK_RED, ChatFormatting.LIGHT_PURPLE,
            ChatFormatting.LIGHT_PURPLE};

    private static float target, shown;
    private static String bonus = "";
    private static int bonusTtl;

    public static void onPacket(float points, int bonusId) {
        target = points;
        if (bonusId >= 0 && bonusId < Style.Bonus.values().length) {
            bonus = Style.Bonus.values()[bonusId].label;
            bonusTtl = 40;
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (Minecraft.getInstance().player == null) {
            target = shown = 0;
            bonusTtl = 0;
            return;
        }
        shown += (target - shown) * 0.3f;
        if (bonusTtl > 0) bonusTtl--;
    }

    /** Rank + progress bar + latest bonus, or null when the meter is empty. */
    public static Component component() {
        if (shown < 1f && bonusTtl <= 0) return null;
        int r = Style.rankOf(shown);
        float lo = Style.RANK_AT[r];
        float hi = r + 1 < Style.RANK_AT.length ? Style.RANK_AT[r + 1] : lo + 100f;
        int filled = Math.round(10 * Math.max(0f, Math.min(1f, (shown - lo) / (hi - lo))));

        MutableComponent c = Component.literal(LETTERS[r] + " " + NAMES[r] + " ").withStyle(COLORS[r], ChatFormatting.BOLD);
        c.append(Component.literal("[" + "#".repeat(filled) + "-".repeat(10 - filled) + "]").withStyle(COLORS[r]));
        if (bonusTtl > 0) c.append(Component.literal(" " + bonus).withStyle(ChatFormatting.YELLOW));
        return c;
    }
}
