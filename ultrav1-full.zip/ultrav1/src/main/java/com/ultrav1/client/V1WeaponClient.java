package com.ultrav1.client;

import com.ultrav1.UltraV1;
import com.ultrav1.network.FirePacket;
import com.ultrav1.network.V1Network;
import com.ultrav1.weapon.V1WeaponItem;
import com.ultrav1.weapon.Weapon;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/** LMB = primary fire, RMB = alternate fire while a V1 weapon is in hand. */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1WeaponClient {
    private static boolean atkWas, useWas;

    public static V1WeaponItem held() {
        LocalPlayer p = Minecraft.getInstance().player;
        return p != null && p.getMainHandItem().getItem() instanceof V1WeaponItem w ? w : null;
    }

    /** Stop vanilla attack / block placing / item use while holding a gun. */
    @SubscribeEvent
    public static void interact(InputEvent.InteractionKeyMappingTriggered e) {
        if (held() != null && (e.isAttack() || e.isUseItem())) {
            e.setCanceled(true);
            e.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        V1WeaponItem w = held();
        if (w == null || mc.screen != null || mc.isPaused()) {
            atkWas = useWas = false;
            return;
        }
        boolean atk = mc.options.keyAttack.isDown();
        boolean use = mc.options.keyUse.isDown();

        if (atk) {
            V1Network.CHANNEL.send(new FirePacket(false, !atkWas), PacketDistributor.SERVER.noArg());
            if (!mc.player.getCooldowns().isOnCooldown(w)) mc.player.swing(InteractionHand.MAIN_HAND);
        }
        if (use && w.weapon.family != Weapon.Family.RAILCANNON) { // railcannon: RMB = zoom
            V1Network.CHANNEL.send(new FirePacket(true, !useWas), PacketDistributor.SERVER.noArg());
        }
        atkWas = atk;
        useWas = use;
    }
}
