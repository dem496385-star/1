package com.ultrav1.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.ultrav1.UltraV1;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class V1Keys {
    // Dash = Left Shift (same as vanilla Sneak), Slide/Slam = Left Ctrl (same as vanilla Sprint).
    // Rebind Sneak and Sprint in Controls (e.g. to X and Z) so they do not fire together.
    public static final KeyMapping DASH = new KeyMapping("key.ultrav1.dash",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_SHIFT, "key.categories.ultrav1");
    public static final KeyMapping SLIDE = new KeyMapping("key.ultrav1.slide",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_CONTROL, "key.categories.ultrav1");

    // Punch = V, Swap arm = G (F and Q are taken by vanilla)
    public static final KeyMapping PUNCH = new KeyMapping("key.ultrav1.punch",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.ultrav1");
    public static final KeyMapping SWAP_ARM = new KeyMapping("key.ultrav1.swap_arm",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.ultrav1");

    // Whiplash = R
    public static final KeyMapping WHIPLASH = new KeyMapping("key.ultrav1.whiplash",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.ultrav1");

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(DASH);
        e.register(SLIDE);
        e.register(PUNCH);
        e.register(SWAP_ARM);
        e.register(WHIPLASH);
    }
}
