package com.ultrav1.client;

import com.ultrav1.UltraV1;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

/** Screen shake, FOV kicks, screen flash and particle effects for the V1 movement. */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1Effects {
    private static final RandomSource R = RandomSource.create();
    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.25f, 0.7f, 1f), 1.2f);
    private static final DustParticleOptions ORANGE = new DustParticleOptions(new Vector3f(1f, 0.45f, 0.05f), 1.4f);

    private static float shake;          // camera shake amplitude (degrees)
    public static float flash;           // white-orange screen flash, 0..1
    private static float fov;            // smoothed FOV offset
    private static float roll;           // smoothed camera roll

    /** Called by the server (FxPacket): parry flash, shockwave shake. */
    public static void fx(float flashAmount, float shakeAmount) {
        flash = Math.max(flash, flashAmount);
        shake = Math.max(shake, shakeAmount);
    }

    // ---------- one-shot hooks (called from V1Movement) ----------
    public static void onDash(LocalPlayer p) {
        shake = Math.max(shake, 0.5f);
        ClientLevel l = (ClientLevel) p.level();
        for (int i = 0; i < 14; i++) {
            l.addParticle(BLUE, p.getX() + rnd(0.5), p.getY() + R.nextDouble() * 1.8, p.getZ() + rnd(0.5), 0, 0, 0);
        }
    }

    public static void onSlamStart(LocalPlayer p) {
        shake = Math.max(shake, 0.4f);
    }

    public static void onSlamImpact(LocalPlayer p, float height) {
        shake = Math.max(shake, Math.min(2f + height * 0.15f, 8f));
        flash = Math.max(flash, 0.45f);
        ClientLevel l = (ClientLevel) p.level();
        for (int i = 0; i < 30; i++) {
            double a = R.nextDouble() * Math.PI * 2, s = 0.15 + R.nextDouble() * 0.3;
            l.addParticle(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 0.1, p.getZ(), Math.cos(a) * s, 0.05, Math.sin(a) * s);
        }
    }

    public static void onWallJump(LocalPlayer p, Vec3 n) {
        shake = Math.max(shake, 0.4f);
        ClientLevel l = (ClientLevel) p.level();
        for (int i = 0; i < 10; i++) {
            l.addParticle(ParticleTypes.POOF, p.getX() - n.x * 0.35 + rnd(0.2), p.getY() + 0.5 + R.nextDouble(),
                    p.getZ() - n.z * 0.35 + rnd(0.2), n.x * 0.05, 0.02, n.z * 0.05);
        }
    }

    public static void onLaunch(LocalPlayer p, float height) {
        shake = Math.max(shake, 1f + height * 0.06f);
        flash = Math.max(flash, 0.35f);
        ClientLevel l = (ClientLevel) p.level();
        for (int i = 0; i < 40; i++) {
            double a = R.nextDouble() * Math.PI * 2, s = 0.1 + R.nextDouble() * 0.35;
            l.addParticle(i % 2 == 0 ? ORANGE : ParticleTypes.FLAME, p.getX(), p.getY() + 0.2, p.getZ(),
                    Math.cos(a) * s, 0.1 + R.nextDouble() * 0.3, Math.sin(a) * s);
        }
    }

    // ---------- continuous effects ----------
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null || Minecraft.getInstance().isPaused()) return;
        ClientLevel l = (ClientLevel) p.level();

        float fovTarget = 0f, rollTarget = 0f;
        Vec3 v = p.getDeltaMovement();
        double speed = Math.sqrt(v.x * v.x + v.z * v.z);

        if (V1Movement.isDashing()) {
            fovTarget += 0.30f;
            for (int i = 0; i < 3; i++) {
                l.addParticle(ParticleTypes.END_ROD, p.getX() + rnd(0.4), p.getY() + R.nextDouble() * 1.8,
                        p.getZ() + rnd(0.4), -v.x * 0.15, 0, -v.z * 0.15);
                l.addParticle(BLUE, p.getX() + rnd(0.4), p.getY() + R.nextDouble() * 1.8, p.getZ() + rnd(0.4), 0, 0, 0);
            }
        }
        if (V1Movement.isSlamming()) {
            fovTarget += 0.25f;
            shake = Math.max(shake, 0.25f);
            l.addParticle(ParticleTypes.FLAME, p.getX() + rnd(0.3), p.getY() + 1.2, p.getZ() + rnd(0.3), 0, 0.2, 0);
            l.addParticle(ParticleTypes.SMOKE, p.getX() + rnd(0.3), p.getY() + 2.0, p.getZ() + rnd(0.3), 0, 0.1, 0);
        }
        if (V1Movement.isSliding()) {
            fovTarget += 0.12f;
            rollTarget = 3f;
            for (int i = 0; i < 2; i++) {
                l.addParticle(ParticleTypes.ELECTRIC_SPARK, p.getX() + rnd(0.3), p.getY() + 0.05, p.getZ() + rnd(0.3),
                        -v.x * 0.3 + rnd(0.1), 0.12, -v.z * 0.3 + rnd(0.1));
            }
            l.addParticle(ParticleTypes.SMOKE, p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.02, 0);
        }
        if (V1Movement.isSlamStored()) {
            double a = (p.tickCount * 0.5) % (Math.PI * 2);
            l.addParticle(ParticleTypes.FLAME, p.getX() + Math.cos(a) * 0.7, p.getY() + 0.9 + rnd(0.7),
                    p.getZ() + Math.sin(a) * 0.7, 0, 0.02, 0);
            shake = Math.max(shake, 0.12f);
        }
        fovTarget += (float) Mth.clamp((speed - 0.6) * 0.3, 0, 0.2);

        fov += (fovTarget - fov) * 0.25f;
        roll += (rollTarget - roll) * 0.2f;
        shake *= 0.85f;
        if (shake < 0.02f) shake = 0;
        flash *= 0.82f;
        if (flash < 0.02f) flash = 0;
    }

    @SubscribeEvent
    public static void fov(ComputeFovModifierEvent e) {
        float m = e.getNewFovModifier() * (1f + fov);
        com.ultrav1.weapon.V1WeaponItem w = V1WeaponClient.held();
        if (w != null && w.weapon.family == com.ultrav1.weapon.Weapon.Family.RAILCANNON
                && Minecraft.getInstance().options.keyUse.isDown()) {
            m *= 0.5f; // railcannon alt fire = 2x zoom
        }
        e.setNewFovModifier(m);
    }

    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles e) {
        if (shake > 0) {
            e.setYaw(e.getYaw() + (R.nextFloat() - 0.5f) * 2f * shake * 0.5f);
            e.setPitch(e.getPitch() + (R.nextFloat() - 0.5f) * 2f * shake * 0.5f);
            e.setRoll(e.getRoll() + (R.nextFloat() - 0.5f) * 2f * shake);
        }
        e.setRoll(e.getRoll() + roll);
    }

    private static double rnd(double r) {
        return (R.nextDouble() - 0.5) * 2 * r;
    }
}
