package com.ultrav1.client;

import com.ultrav1.UltraV1;
import com.ultrav1.network.ArmPacket;
import com.ultrav1.network.V1Network;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/** Punch key (V) and arm swap key (G). Works with any item in hand. */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1ArmsClient {
    private static boolean was;

    private static void send(int action) {
        V1Network.CHANNEL.send(new ArmPacket(action), PacketDistributor.SERVER.noArg());
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || mc.isPaused()) {
            if (was) send(1);
            was = false;
            return;
        }
        while (V1Keys.SWAP_ARM.consumeClick()) send(2);

        boolean down = V1Keys.PUNCH.isDown();
        if (down && !was) {
            send(0);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
        if (!down && was) send(1);
        was = down;
    }
}
