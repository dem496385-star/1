package com.ultrav1.client;

import com.ultrav1.UltraV1;
import com.ultrav1.network.ArmPacket;
import com.ultrav1.network.V1Network;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/** Whiplash key (R): hold to throw, release to pull. Also runs the reeling movement. */
@Mod.EventBusSubscriber(modid = UltraV1.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class V1WhipClient {
    private static final double REEL_SPEED = 1.0;   // blocks per tick
    private static final int MAX_REEL_TICKS = 80;

    private static boolean reeling, was, jumpWas;
    private static Vec3 target = Vec3.ZERO;
    private static int reelTicks;

    public static boolean isReeling() { return reeling; }

    private static void send(int action) {
        V1Network.CHANNEL.send(new ArmPacket(action), PacketDistributor.SERVER.noArg());
    }

    /** Called from WhipPacket on the client thread. */
    public static void onPacket(boolean reel, float x, float y, float z) {
        if (reel) {
            reeling = true;
            reelTicks = 0;
            target = new Vec3(x, y, z);
            jumpWas = Minecraft.getInstance().options.keyJump.isDown();
        } else {
            reeling = false;
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null || mc.isPaused()) {
            if (was) send(4);
            was = false;
            reeling = false;
            return;
        }

        boolean down = V1Keys.WHIPLASH.isDown();
        if (reeling) {
            if (down && !was) { reeling = false; send(5); } // key again = cancel
        } else {
            if (down && !was) send(3);
            if (!down && was) send(4);
        }
        was = down;

        if (!reeling) return;

        boolean jump = mc.options.keyJump.isDown();
        boolean jumpPress = jump && !jumpWas;
        jumpWas = jump;

        Vec3 center = p.position().add(0, p.getBbHeight() * 0.5, 0);
        Vec3 to = target.subtract(center);
        double d = to.length();
        reelTicks++;

        if (jumpPress) { // jump cancels the pull: small hop, lose most momentum
            Vec3 v = p.getDeltaMovement();
            p.setDeltaMovement(v.x * 0.3, 0.55, v.z * 0.3);
            reeling = false;
            send(5);
            return;
        }
        if (d < 1.6 || reelTicks > MAX_REEL_TICKS || (reelTicks > 4 && p.horizontalCollision && d < 4)) {
            p.setDeltaMovement(p.getDeltaMovement().scale(0.6));
            reeling = false;
            send(5);
            return;
        }
        p.setDeltaMovement(to.normalize().scale(REEL_SPEED));
        p.fallDistance = 0;
        p.level().addParticle(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.9, p.getZ(), 0, 0, 0);
    }
}
