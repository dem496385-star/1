package com.ultrav1;

import net.minecraftforge.common.ForgeConfigSpec;

/** Balance settings: edit config/ultrav1-common.toml (no recompiling needed). */
public final class V1Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue DAMAGE_SCALE;
    public static final ForgeConfigSpec.DoubleValue SELF_EXPLOSION_SCALE;
    public static final ForgeConfigSpec.BooleanValue PARRY_FULL_HEAL;
    public static final ForgeConfigSpec.IntValue RAIL_COOLDOWN;
    public static final ForgeConfigSpec.IntValue ROCKET_COOLDOWN;
    public static final ForgeConfigSpec.DoubleValue BLOOD_HARD_FRACTION;
    public static final ForgeConfigSpec.DoubleValue BLOOD_HEAL_PER_DAMAGE;
    public static final ForgeConfigSpec.BooleanValue STYLE_ENABLED;
    public static final ForgeConfigSpec.DoubleValue STYLE_DECAY;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("balance");
        DAMAGE_SCALE = b.comment("Multiplier for all weapon / arm damage (1.0 = 1 ULTRAKILL damage is 4 HP)")
                .defineInRange("damageScale", 1.0, 0.1, 10.0);
        SELF_EXPLOSION_SCALE = b.comment("Multiplier for damage you take from your own explosions (rocket jumps). 0 = none")
                .defineInRange("selfExplosionScale", 1.0, 0.0, 10.0);
        PARRY_FULL_HEAL = b.comment("A parry heals you to full health (false = heals 10 HP)")
                .define("parryFullHeal", true);
        RAIL_COOLDOWN = b.comment("Railcannon cooldown in ticks (20 ticks = 1 s)")
                .defineInRange("railcannonCooldownTicks", 320, 1, 6000);
        ROCKET_COOLDOWN = b.comment("Rocket launcher cooldown in ticks")
                .defineInRange("rocketCooldownTicks", 20, 1, 600);
        BLOOD_HARD_FRACTION = b.comment("Share of the damage you take that blood can heal back")
                .defineInRange("bloodHardFraction", 0.6, 0.0, 1.0);
        BLOOD_HEAL_PER_DAMAGE = b.comment("HP healed per HP of damage you deal (limited by hard damage)")
                .defineInRange("bloodHealPerDamage", 0.25, 0.0, 5.0);
        b.pop();
        b.push("style");
        STYLE_ENABLED = b.comment("Show and track the style meter").define("enabled", true);
        STYLE_DECAY = b.comment("How fast style points drain (1.0 = default)")
                .defineInRange("decayScale", 1.0, 0.0, 10.0);
        b.pop();
        SPEC = b.build();
    }

    private V1Config() {}
}
