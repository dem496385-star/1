package com.ultrav1.server;

import com.ultrav1.V1Config;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Blood healing, ULTRAKILL style: part of the damage you take becomes "hard damage".
 * Hurting enemies heals you back, but only up to that recoverable amount.
 * Parrying heals fully regardless.
 */
public final class Blood {
    private static float hardFraction() { return V1Config.BLOOD_HARD_FRACTION.get().floatValue(); }
    private static float healPerDamage() { return V1Config.BLOOD_HEAL_PER_DAMAGE.get().floatValue(); }
    private static final float MAX_HEAL_PER_HIT = 1.0f;

    private static final Map<UUID, Float> HARD = new HashMap<>();

    public static void onHurt(ServerPlayer p, float amount) {
        float after = Math.max(0f, p.getHealth() - amount);
        float cap = p.getMaxHealth() - after;
        HARD.put(p.getUUID(), Math.min(cap, HARD.getOrDefault(p.getUUID(), 0f) + amount * hardFraction()));
    }

    public static void onDealt(ServerPlayer p, float dmg) {
        Float h = HARD.get(p.getUUID());
        if (h == null || h <= 0f || p.getHealth() >= p.getMaxHealth()) return;
        float heal = Math.min(h, Math.min(dmg * healPerDamage(), MAX_HEAL_PER_HIT));
        if (heal <= 0f) return;
        p.heal(heal);
        HARD.put(p.getUUID(), h - heal);
    }

    public static void tick(ServerPlayer p) {
        if (p.getHealth() >= p.getMaxHealth()) HARD.remove(p.getUUID());
    }

    public static void forget(UUID id) { HARD.remove(id); }

    public static void clear() { HARD.clear(); }

    private Blood() {}
}
