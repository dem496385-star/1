package com.ultrav1.server;

import com.ultrav1.network.V1Network;
import com.ultrav1.network.WhipPacket;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Whiplash (green arm): hold to throw the hook, release to pull.
 * Light enemies are pulled to you; heavy enemies and surfaces pull YOU (reeling runs on the client).
 */
public final class WhipLogic {
    private static final double RANGE = 40;
    private static final int COOLDOWN = 10;   // 0.5 s
    private static final int MAX_HOLD = 100;
    private static final DustParticleOptions GREEN = new DustParticleOptions(new Vector3f(0.25f, 0.9f, 0.35f), 1.2f);

    private static final class St {
        boolean hooked;
        UUID ent;          // hooked entity, or null when hooked to a surface
        Vec3 point;
        long since, cd;
        UUID pulling;      // light enemy being reeled in
        long pullSince;
    }

    private static final Map<UUID, St> STATE = new HashMap<>();

    public static void clear() { STATE.clear(); }

    public static void forget(UUID id) { STATE.remove(id); }

    public static void handle(ServerPlayer p, int action) {
        if (!p.isAlive() || p.isSpectator()) return;
        St s = STATE.computeIfAbsent(p.getUUID(), k -> new St());
        long now = p.level().getGameTime();
        switch (action) {
            case 3 -> throwHook(p, s, now);
            case 4 -> release(p, s, now);
            case 5 -> cancel(p);
            default -> { }
        }
    }

    private static void throwHook(ServerPlayer p, St s, long now) {
        if (now < s.cd || s.hooked) return;
        s.pulling = null;
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        BlockHitResult b = l.clip(new ClipContext(eye, eye.add(look.scale(RANGE)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean blockHit = b.getType() != HitResult.Type.MISS;
        double bd = blockHit ? eye.distanceTo(b.getLocation()) : RANGE;
        LivingEntity e = Combat.rayEntity(p, RANGE);
        double ed = e == null ? Double.MAX_VALUE : eye.distanceTo(e.position().add(0, e.getBbHeight() * 0.5, 0));

        if (e != null && ed <= bd + 0.5) {
            s.ent = e.getUUID();
            s.point = null;
            Combat.damage(p, e, 0.8f); // 0.2 damage
        } else if (blockHit) {
            s.ent = null;
            s.point = b.getLocation();
        } else {
            s.cd = now + COOLDOWN;
            return;
        }
        s.hooked = true;
        s.since = now;
        Combat.sound(l, eye, SoundEvents.CROSSBOW_SHOOT, 0.6f, 0.6f);
    }

    private static void release(ServerPlayer p, St s, long now) {
        if (!s.hooked) return;
        s.hooked = false;
        s.cd = now + COOLDOWN;
        ServerLevel l = (ServerLevel) p.level();
        if (s.ent != null) {
            Entity e = l.getEntity(s.ent);
            if (e instanceof LivingEntity le && le.isAlive()) {
                if (isLight(le)) {
                    s.pulling = le.getUUID();
                    s.pullSince = now;
                } else {
                    reel(p, le.position().add(0, le.getBbHeight() * 0.5, 0));
                }
            }
        } else if (s.point != null) {
            reel(p, s.point);
        }
    }

    /** Used by the arms: punching cancels the whiplash. */
    public static void cancel(ServerPlayer p) {
        St s = STATE.get(p.getUUID());
        if (s == null) return;
        boolean active = s.hooked || s.pulling != null;
        s.hooked = false;
        s.pulling = null;
        s.cd = p.level().getGameTime() + COOLDOWN;
        if (active) V1Network.CHANNEL.send(new WhipPacket(false, 0, 0, 0), PacketDistributor.PLAYER.with(p));
    }

    private static boolean isLight(LivingEntity e) {
        return e.getBbWidth() * e.getBbWidth() * e.getBbHeight() < 2.5f && e.getMaxHealth() <= 60f;
    }

    private static void reel(ServerPlayer p, Vec3 target) {
        V1Network.CHANNEL.send(new WhipPacket(true, (float) target.x, (float) target.y, (float) target.z),
                PacketDistributor.PLAYER.with(p));
        Combat.sound((ServerLevel) p.level(), p.getEyePosition(), SoundEvents.PISTON_EXTEND, 0.8f, 1.8f);
    }

    public static void tick(ServerPlayer p) {
        St s = STATE.get(p.getUUID());
        if (s == null) return;
        ServerLevel l = (ServerLevel) p.level();
        long now = l.getGameTime();
        Vec3 eye = p.getEyePosition();
        Vec3 hand = eye.add(0, -0.3, 0).add(p.getLookAngle().scale(0.4));

        if (s.hooked) {
            Vec3 target = s.point;
            if (s.ent != null) {
                Entity e = l.getEntity(s.ent);
                if (!(e instanceof LivingEntity le) || !le.isAlive()) { cancel(p); return; }
                target = le.position().add(0, le.getBbHeight() * 0.5, 0);
            }
            if (now - s.since > MAX_HOLD || target.distanceTo(eye) > RANGE + 5) {
                cancel(p);
                Status.send(p, "WHIPLASH LOST");
                return;
            }
            Combat.line(l, hand, target, GREEN, 0.8);
        }

        if (s.pulling != null) {
            Entity e = l.getEntity(s.pulling);
            if (!(e instanceof LivingEntity le) || !le.isAlive() || now - s.pullSince > 40) {
                s.pulling = null;
                return;
            }
            Vec3 to = p.position().add(0, 0.5, 0).subtract(le.position());
            if (to.length() < 2.2) {
                s.pulling = null;
                le.setDeltaMovement(Vec3.ZERO);
                le.hurtMarked = true;
                return;
            }
            le.setDeltaMovement(to.normalize().scale(1.5));
            le.fallDistance = 0;
            le.hurtMarked = true;
            Combat.line(l, hand, le.position().add(0, le.getBbHeight() * 0.5, 0), GREEN, 0.8);
        }
    }

    private WhipLogic() {}
}
