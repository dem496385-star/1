package com.ultrav1.server;

import com.ultrav1.V1Config;
import com.ultrav1.server.Projectiles.Kind;
import com.ultrav1.weapon.ModItems;
import com.ultrav1.weapon.V1WeaponItem;
import com.ultrav1.weapon.Weapon;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Primary / alternate fire of all 15 variants. 1 ULTRAKILL damage = 4 HP. */
public final class WeaponLogic {
    private static int railCd() { return V1Config.RAIL_COOLDOWN.get(); }     // shared by all railcannons
    private static int rocketCd() { return V1Config.ROCKET_COOLDOWN.get(); } // shared by all rocket launchers

    private static final class St {
        final long[] alt = new long[Weapon.values().length];
        long lastFire;
        int pump;                 // Pump Charge: pumps stored (0..2)
        float heat;               // shared by all nailguns
        int sinks = 2, sinkRegen; // Overheat heatsinks
        int burst;                // ticks of heatsink burst left
        int spin;                 // Sharpshooter spin level 0..3
        long spinUntil;
        UUID tether;              // JumpStart cable target
        long tetherStart, tetherCd;
    }

    private static final Map<UUID, St> STATE = new HashMap<>();

    private static St st(ServerPlayer p) { return STATE.computeIfAbsent(p.getUUID(), k -> new St()); }

    public static void clear() { STATE.clear(); }

    public static void forget(UUID id) { STATE.remove(id); }

    public static void fire(ServerPlayer p, boolean alt, boolean press) {
        if (!p.isAlive() || p.isSpectator()) return;
        if (!(p.getMainHandItem().getItem() instanceof V1WeaponItem it)) return;
        Weapon w = it.weapon;
        St s = st(p);
        long now = p.level().getGameTime();
        if (alt) secondary(p, w, s, now, press);
        else primary(p, w, s, now);
    }

    private static void cd(ServerPlayer p, Weapon w, int ticks) {
        if (w.family == Weapon.Family.RAILCANNON || w.family == Weapon.Family.ROCKET) {
            for (Weapon o : Weapon.values()) {
                if (o.family == w.family) p.getCooldowns().addCooldown(ModItems.get(o), ticks);
            }
        } else {
            p.getCooldowns().addCooldown(ModItems.get(w), ticks);
        }
    }

    private static void bar(ServerPlayer p, String text) {
        Status.send(p, text);
    }

    // =====================================================================
    // PRIMARY FIRE
    // =====================================================================
    private static void primary(ServerPlayer p, Weapon w, St s, long now) {
        Item item = p.getMainHandItem().getItem();
        if (p.getCooldowns().isOnCooldown(item)) return;
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        s.lastFire = now;

        switch (w) {
            // ---- revolvers ----
            case PIERCER -> {
                Combat.trace(p, eye, look, 150, new Combat.Opts(4f, w.dust()).head(2f));
                Combat.sound(l, eye, SoundEvents.CROSSBOW_SHOOT, 0.8f, 1.6f);
                cd(p, w, 10);
            }
            case MARKSMAN -> {
                Combat.trace(p, eye, look, 150, new Combat.Opts(3.5f, w.dust()).head(2f));
                Combat.sound(l, eye, SoundEvents.CROSSBOW_SHOOT, 0.8f, 1.9f);
                cd(p, w, 8);
            }
            case SHARPSHOOTER -> {
                int spin = now < s.spinUntil ? s.spin : 0;
                Combat.trace(p, eye, look, 150, new Combat.Opts(5f, w.dust()).pierce(3).ricochet(1 + spin).head(1.5f));
                Combat.sound(l, eye, SoundEvents.CROSSBOW_SHOOT, 0.9f, 1.3f);
                cd(p, w, 14);
            }

            // ---- shotguns ----
            case CORE_EJECT, SAWED_ON -> {
                pellets(p, w, 12);
                cd(p, w, 25);
            }
            case PUMP_CHARGE -> {
                pellets(p, w, s.pump == 0 ? 10 : s.pump == 1 ? 16 : 24);
                s.pump = 0;
                cd(p, w, 18);
            }

            // ---- nailguns ----
            case ATTRACTOR -> {
                nail(p, w, 0.03, 2.6, 1.0f, false, 80);
                s.heat = Math.min(1f, s.heat + 0.012f);
                nailSound(l, eye, now);
                cd(p, w, 1);
            }
            case OVERHEAT -> {
                nail(p, w, 0.03, 2.6, 0.8f, false, 80);
                s.heat = Math.min(1f, s.heat + 0.012f);
                nailSound(l, eye, now);
                cd(p, w, s.sinks == 0 ? 3 : s.heat > 0.5f ? 2 : 1);
            }
            case JUMPSTART -> {
                boolean tethered = s.tether != null;
                nail(p, w, 0.03, 2.6, 0.8f, false, 80);
                if (tethered) s.heat = Math.min(1f, s.heat + 0.012f);
                nailSound(l, eye, now);
                cd(p, w, tethered ? 1 : 2);
            }

            // ---- railcannons (16 s shared cooldown) ----
            case ELECTRIC -> {
                Combat.trace(p, eye, look, 120, new Combat.Opts(32f, Combat.ELEC).pierce(99).inflate(0.25).step(0.4));
                l.sendParticles(ParticleTypes.ELECTRIC_SPARK, eye.x + look.x, eye.y + look.y, eye.z + look.z, 20, 0.3, 0.3, 0.3, 0.2);
                Combat.sound(l, eye, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 1.8f);
                cd(p, w, railCd());
            }
            case SCREWDRIVER -> {
                Projectiles.spawn(Kind.DRILL, p, eye.add(look.scale(0.8)), look.scale(2.4), 60, 0);
                Combat.sound(l, eye, SoundEvents.ANVIL_LAND, 0.8f, 1.8f);
                cd(p, w, railCd());
            }
            case MALICIOUS -> {
                Combat.Result r = Combat.trace(p, eye, look, 120,
                        new Combat.Opts(8f, w.dust()).pierce(1).inflate(0.25).step(0.4));
                Combat.explode(p, l, r.end, 5.5, 25f, true, false);
                Combat.sound(l, eye, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 1.2f);
                cd(p, w, railCd());
            }

            // ---- rocket launchers (1 s shared cooldown) ----
            case FREEZEFRAME, SRS, FIRESTARTER -> {
                Projectiles.spawn(Kind.ROCKET, p, eye.add(look.scale(0.8)), look.scale(1.5), 200, 0);
                Combat.sound(l, eye, SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 0.8f);
                cd(p, w, rocketCd());
            }
        }
    }

    private static void pellets(ServerPlayer p, Weapon w, int n) {
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        var r = p.getRandom();
        for (int i = 0; i < n; i++) {
            Vec3 d = look.add(r.nextGaussian() * 0.06, r.nextGaussian() * 0.06, r.nextGaussian() * 0.06).normalize();
            Combat.trace(p, eye, d, 28, new Combat.Opts(1f, w.dust()).step(1.6));
        }
        Combat.sound(l, eye, SoundEvents.FIREWORK_ROCKET_BLAST, 1.0f, 0.9f);
        l.sendParticles(ParticleTypes.SMOKE, eye.x + look.x, eye.y + look.y, eye.z + look.z, 6, 0.1, 0.1, 0.1, 0.02);
    }

    private static void nail(ServerPlayer p, Weapon w, double spread, double speed, float dmg, boolean flaming, int ttl) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        var r = p.getRandom();
        Vec3 d = look.add(r.nextGaussian() * spread, r.nextGaussian() * spread, r.nextGaussian() * spread).normalize();
        Projectiles.Proj pr = Projectiles.spawn(Kind.NAIL, p, eye.add(look.scale(0.8)).add(0, -0.1, 0), d.scale(speed), ttl, dmg);
        pr.flaming = flaming;
    }

    private static void nailSound(ServerLevel l, Vec3 at, long now) {
        if (now % 3 == 0) Combat.sound(l, at, SoundEvents.CROSSBOW_SHOOT, 0.35f, 2.0f);
    }

    // =====================================================================
    // ALTERNATE FIRE
    // =====================================================================
    private static void secondary(ServerPlayer p, Weapon w, St s, long now, boolean press) {
        if (now < s.alt[w.ordinal()]) return;
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        UUID id = p.getUUID();

        switch (w) {
            case PIERCER -> { // charged piercing shot
                if (!press) return;
                Combat.trace(p, eye, look, 150, new Combat.Opts(20f, w.dust()).pierce(99).inflate(0.25).head(1.5f).step(0.4));
                Combat.sound(l, eye, SoundEvents.CROSSBOW_SHOOT, 1.2f, 0.8f);
                s.alt[w.ordinal()] = now + 100;
                s.lastFire = now;
            }
            case MARKSMAN -> { // coin toss; shoot the coin to ricochet
                if (!press) return;
                if (Projectiles.countOwned(Kind.COIN, id) >= 4) Projectiles.killOldest(Kind.COIN, id);
                Vec3 v = look.scale(0.35).add(0, 0.32, 0);
                Projectiles.spawn(Kind.COIN, p, eye.add(look.scale(0.5)), v, 50, 0);
                Combat.sound(l, eye, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7f, 1.8f);
                s.alt[w.ordinal()] = now + 10;
            }
            case SHARPSHOOTER -> { // spin the revolver: more ricochets
                if (!press) return;
                s.spin = Math.min(3, (now < s.spinUntil ? s.spin : 0) + 1);
                s.spinUntil = now + 60;
                bar(p, "SPIN " + "|".repeat(s.spin) + ".".repeat(3 - s.spin));
                Combat.sound(l, eye, SoundEvents.PISTON_EXTEND, 0.4f, 2.0f);
                s.alt[w.ordinal()] = now + 4;
            }

            case CORE_EJECT -> { // explosive core, shoot it for a bigger blast
                if (!press) return;
                Vec3 v = look.scale(1.3).add(p.getDeltaMovement().scale(0.5));
                Projectiles.spawn(Kind.CORE, p, eye.add(look.scale(0.6)), v, 80, 0);
                Combat.sound(l, eye, SoundEvents.FIREWORK_ROCKET_LAUNCH, 0.8f, 1.2f);
                s.alt[w.ordinal()] = now + 40;
            }
            case PUMP_CHARGE -> { // pump: more pellets, 3 pumps = overpump explosion
                if (!press) return;
                s.pump++;
                if (s.pump >= 3) {
                    s.pump = 0;
                    Combat.explode(p, l, p.position().add(0, 1, 0), 5.0, 40f, true, true);
                    bar(p, "OVERPUMP!");
                } else {
                    bar(p, "PUMP " + "|".repeat(s.pump) + ".".repeat(3 - s.pump));
                    Combat.sound(l, eye, SoundEvents.PISTON_EXTEND, 0.6f, 1.5f);
                }
                s.alt[w.ordinal()] = now + 8;
            }
            case SAWED_ON -> { // launch a chainsaw
                if (!press) return;
                Projectiles.killOldest(Kind.CHAINSAW, id);
                Projectiles.spawn(Kind.CHAINSAW, p, eye.add(look.scale(0.7)), look.scale(1.3), 80, 0);
                Combat.sound(l, eye, SoundEvents.ANVIL_LAND, 0.8f, 1.6f);
                s.alt[w.ordinal()] = now + 80;
            }

            case ATTRACTOR -> { // up to 3 magnets
                if (!press) return;
                if (Projectiles.countOwned(Kind.MAGNET, id) >= 3) return;
                Projectiles.spawn(Kind.MAGNET, p, eye.add(look.scale(0.6)), look.scale(1.6), 40, 0);
                Combat.sound(l, eye, SoundEvents.PISTON_EXTEND, 0.6f, 1.2f);
                s.alt[w.ordinal()] = now + 7;
            }
            case OVERHEAT -> { // heatsink burst of flaming nails
                if (!press) return;
                if (s.sinks <= 0 || s.heat < 0.25f) { bar(p, "NOT HOT ENOUGH"); return; }
                s.sinks--;
                s.burst = 6 + (int) (14 * s.heat);
                s.heat = 0;
                bar(p, "HEATSINKS " + s.sinks + "/2");
                s.alt[w.ordinal()] = now + 10;
            }
            case JUMPSTART -> { // cable that charges a shock
                if (!press || s.tether != null) return;
                if (now < s.tetherCd) { bar(p, "CABLE COOLING DOWN"); return; }
                LivingEntity t = Combat.rayEntity(p, 20);
                if (t != null) {
                    s.tether = t.getUUID();
                    s.tetherStart = now;
                    bar(p, "CONNECTED");
                    Combat.sound(l, eye, SoundEvents.PISTON_EXTEND, 0.8f, 1.8f);
                }
                s.alt[w.ordinal()] = now + 4;
            }

            case ELECTRIC, SCREWDRIVER, MALICIOUS -> { } // alt = zoom (client side)

            case FREEZEFRAME -> { // freeze / release rockets
                if (!press) return;
                Projectiles.toggleFreeze(id);
                Combat.sound(l, eye, SoundEvents.GLASS_BREAK, 0.5f, 1.8f);
                s.alt[w.ordinal()] = now + 6;
            }
            case SRS -> { // cannonball that bounces off enemies
                if (!press) return;
                Projectiles.spawn(Kind.CANNONBALL, p, eye.add(look.scale(0.8)), look.scale(1.9), 100, 0);
                Combat.sound(l, eye, SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.0f, 0.6f);
                s.alt[w.ordinal()] = now + 60;
            }
            case FIRESTARTER -> { // spray gasoline (hold)
                var r = p.getRandom();
                for (int i = 0; i < 2; i++) {
                    Vec3 d = look.add(r.nextGaussian() * 0.07, r.nextGaussian() * 0.07, r.nextGaussian() * 0.07).normalize();
                    Projectiles.spawn(Kind.GAS, p, eye.add(look.scale(0.7)), d.scale(1.1), 16, 0);
                }
                s.alt[w.ordinal()] = now + 1;
            }
        }
    }

    // =====================================================================
    // per-tick state (heat, heatsink bursts, JumpStart cable)
    // =====================================================================
    public static void playerTick(ServerPlayer p) {
        St s = STATE.get(p.getUUID());
        if (s == null) return;
        ServerLevel l = (ServerLevel) p.level();
        long now = l.getGameTime();

        if (now - s.lastFire > 5 && s.heat > 0) s.heat = Math.max(0f, s.heat - 0.01f);

        if (s.sinks < 2 && now - s.lastFire > 10) {
            if (++s.sinkRegen >= 160) { s.sinks++; s.sinkRegen = 0; }
        } else if (s.sinks >= 2) {
            s.sinkRegen = 0;
        }

        if (s.burst > 0) { // Overheat heatsink: flaming nail spray
            s.burst--;
            for (int i = 0; i < 3; i++) nail(p, Weapon.OVERHEAT, 0.22, 2.0, 0.8f, true, 18);
            if (s.burst % 3 == 0) Combat.sound(l, p.getEyePosition(), SoundEvents.BLAZE_SHOOT, 0.5f, 1.4f);
        }

        if (s.tether != null) {
            var e = l.getEntity(s.tether);
            Vec3 a = p.getEyePosition().add(0, -0.3, 0);
            if (!(e instanceof LivingEntity t) || !t.isAlive() || t.distanceTo(p) > 20) {
                s.tether = null;
                bar(p, "CABLE BROKEN");
            } else {
                Vec3 b = t.position().add(0, t.getBbHeight() * 0.5, 0);
                if (now % 3 == 0) Combat.line(l, a, b, Combat.ELEC, 0.7);
                long left = 100 - (now - s.tetherStart);
                if (now % 10 == 0 && left > 0) bar(p, "SHOCK IN " + String.format("%.1f", left / 20.0) + "s");
                if (left <= 0) {
                    Combat.damage(p, t, 30f);
                    l.sendParticles(ParticleTypes.ELECTRIC_SPARK, b.x, b.y, b.z, 40, 0.5, 0.8, 0.5, 0.4);
                    Combat.sound(l, b, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.7f, 2.0f);
                    s.tether = null;
                    s.tetherCd = now + 100;
                }
            }
        }
    }

    private WeaponLogic() {}
}
