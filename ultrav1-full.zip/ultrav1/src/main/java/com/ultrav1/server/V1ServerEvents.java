package com.ultrav1.server;

import com.ultrav1.weapon.ModItems;
import com.ultrav1.weapon.Weapon;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.joml.Vector3f;

public class V1ServerEvents {
    private static final String SLAM_TAG = "ultrav1_slamming";
    private static final String GIVEN_TAG = "ultrav1_given";

    /** Flag expires after 60 s so a lost packet can never leave fall damage off forever. */
    private static boolean isSlamming(ServerPlayer p) {
        long t = p.getPersistentData().getLong(SLAM_TAG);
        return t > 0 && p.level().getGameTime() - t < 1200;
    }

    public static void startSlam(ServerPlayer p) {
        p.getPersistentData().putLong(SLAM_TAG, p.level().getGameTime());
    }

    public static void slamImpact(ServerPlayer p, float fall) {
        if (!isSlamming(p)) return;
        p.getPersistentData().putLong(SLAM_TAG, 0L);

        float dist = Math.max(0f, Math.min(fall, 60f));
        double radius = Math.min(3.0 + dist * 0.15, 12.0);
        float damage = Math.min(4f + dist * 0.5f, 40f);

        ServerLevel level = (ServerLevel) p.level();
        AABB box = p.getBoundingBox().inflate(radius, 1.5, radius);
        int slammed = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != p)) {
            slammed++;
            e.hurt(p.damageSources().playerAttack(p), damage);
            e.push(0, 0.6, 0);
            e.hurtMarked = true;
            level.sendParticles(new DustParticleOptions(new Vector3f(0.7f, 0f, 0f), 1.5f),
                    e.getX(), e.getY(0.5), e.getZ(), 14, 0.3, 0.4, 0.3, 0.05);
        }
        if (slammed > 0) Style.bonus(p, Style.Bonus.SLAM);
        // a slam pops Attractor magnets
        Projectiles.breakMagnetsNear(level, p.position(), radius + 1);

        DustParticleOptions orange = new DustParticleOptions(new Vector3f(1f, 0.45f, 0.05f), 1.6f);
        for (int ring = 1; ring <= 2; ring++) {
            double rr = radius * ring / 2.0;
            for (int i = 0; i < 48; i++) {
                double a = i * Math.PI * 2 / 48;
                double px = p.getX() + Math.cos(a) * rr, pz = p.getZ() + Math.sin(a) * rr;
                level.sendParticles(orange, px, p.getY() + 0.1, pz, 1, 0, 0.05, 0, 0.02);
                if (i % 4 == 0) level.sendParticles(ParticleTypes.FLAME, px, p.getY() + 0.1, pz, 1, 0, 0.1, 0, 0.03);
            }
        }
        level.sendParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 0.1, p.getZ(), 1, 0, 0, 0, 0);
        level.playSound(null, p.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    /** Part of the damage you take becomes hard damage that blood can heal back. */
    @SubscribeEvent
    public void onDamaged(LivingDamageEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) Blood.onHurt(p, e.getAmount());
    }

    /** Kills made by the player feed the style meter. */
    @SubscribeEvent
    public void onKill(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer p && e.getEntity() != p) Style.bonus(p, Style.Bonus.KILL);
    }

    /** No fall damage while the player is mid-slam. */
    @SubscribeEvent
    public void onFall(LivingFallEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && isSlamming(p)) e.setCanceled(true);
    }

    @SubscribeEvent
    public void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Projectiles.tick();
        for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) {
            WeaponLogic.playerTick(p);
            ArmLogic.tick(p);
            WhipLogic.tick(p);
            Blood.tick(p);
            Style.tick(p);
        }
    }

    /** V1 starts with only the blue revolver (Piercer), once per character. /v1give gives every weapon. */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && !p.getPersistentData().getBoolean(GIVEN_TAG)) {
            ItemStack st = new ItemStack(ModItems.get(Weapon.PIERCER));
            if (!p.getInventory().add(st)) p.drop(st, false);
            p.getPersistentData().putBoolean(GIVEN_TAG, true);
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        WeaponLogic.forget(e.getEntity().getUUID());
        ArmLogic.forget(e.getEntity().getUUID());
        WhipLogic.forget(e.getEntity().getUUID());
        Blood.forget(e.getEntity().getUUID());
        Style.forget(e.getEntity().getUUID());
    }

    @SubscribeEvent
    public void onStop(ServerStoppingEvent e) {
        Projectiles.clear();
        WeaponLogic.clear();
        ArmLogic.clear();
        WhipLogic.clear();
        Blood.clear();
        Style.clear();
    }

    @SubscribeEvent
    public void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("v1give").executes(c -> {
            giveAll(c.getSource().getPlayerOrException());
            return 1;
        }));
    }

    private static void giveAll(ServerPlayer p) {
        for (Weapon w : Weapon.values()) {
            ItemStack st = new ItemStack(ModItems.get(w));
            if (!p.getInventory().add(st)) p.drop(st, false);
        }
    }
}
