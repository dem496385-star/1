package com.ultrav1.server;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * "Virtual" projectiles: simulated on the server and drawn with particles,
 * so no custom entities or renderers are needed.
 */
public final class Projectiles {
    public enum Kind { NAIL, ROCKET, CANNONBALL, CORE, COIN, DRILL, CHAINSAW, MAGNET, GAS }

    public static final class Proj {
        public Kind kind;
        public ServerLevel level;
        public UUID owner;
        public Vec3 pos, vel = Vec3.ZERO, saved = Vec3.ZERO;
        public int ttl, age, bounces, count, noHit;
        public float dmg;
        public boolean dead, stuck, frozen, flaming, released;
        public LivingEntity host;
        public Proj magnet;
    }

    private static final class Hit {
        LivingEntity e; BlockHitResult b; Vec3 point;
    }

    private static final List<Proj> LIST = new ArrayList<>();

    public static void clear() { LIST.clear(); }

    public static Proj spawn(Kind k, ServerPlayer p, Vec3 pos, Vec3 vel, int ttl, float dmg) {
        Proj pr = new Proj();
        pr.kind = k; pr.level = (ServerLevel) p.level(); pr.owner = p.getUUID();
        pr.pos = pos; pr.vel = vel; pr.ttl = ttl; pr.dmg = dmg;
        LIST.add(pr);
        return pr;
    }

    // ---------- queries used by weapon logic ----------
    public static int countOwned(Kind k, UUID owner) {
        int n = 0;
        for (Proj pr : LIST) if (!pr.dead && pr.kind == k && pr.owner.equals(owner)) n++;
        return n;
    }

    public static void killOldest(Kind k, UUID owner) {
        for (Proj pr : LIST) if (!pr.dead && pr.kind == k && pr.owner.equals(owner)) { pr.dead = true; return; }
    }

    public static void toggleFreeze(UUID owner) {
        boolean anyFlying = false;
        for (Proj pr : LIST) if (!pr.dead && pr.kind == Kind.ROCKET && pr.owner.equals(owner) && !pr.frozen) anyFlying = true;
        for (Proj pr : LIST) {
            if (pr.dead || pr.kind != Kind.ROCKET || !pr.owner.equals(owner)) continue;
            if (anyFlying && !pr.frozen) { pr.frozen = true; pr.saved = pr.vel; pr.vel = Vec3.ZERO; pr.ttl = Math.max(pr.ttl, 200); }
            else if (!anyFlying && pr.frozen) { pr.frozen = false; pr.vel = pr.saved; }
        }
    }

    public static void breakMagnetsNear(ServerLevel l, Vec3 c, double r) {
        for (Proj pr : LIST) if (pr.kind == Kind.MAGNET && !pr.dead && pr.level == l && pr.pos.distanceTo(c) <= r) pr.dead = true;
    }

    // ---------- hitscan interaction ----------
    public static Proj firstHit(ServerLevel l, Vec3 s, Vec3 e) {
        Vec3 ab = e.subtract(s);
        double len2 = ab.lengthSqr();
        if (len2 < 1.0E-6) return null;
        Proj best = null;
        double bt = 2;
        for (Proj pr : LIST) {
            if (pr.dead || pr.level != l) continue;
            boolean shootable = pr.kind == Kind.COIN || pr.kind == Kind.CORE
                    || (pr.kind == Kind.MAGNET && pr.stuck) || (pr.kind == Kind.ROCKET && pr.frozen);
            if (!shootable) continue;
            double t = Math.max(0, Math.min(1, pr.pos.subtract(s).dot(ab) / len2));
            if (s.add(ab.scale(t)).distanceTo(pr.pos) < 0.8 && t < bt) { bt = t; best = pr; }
        }
        return best;
    }

    public static void onShot(ServerPlayer p, Proj pr, float dmg) {
        ServerLevel l = pr.level;
        switch (pr.kind) {
            case COIN -> { pr.dead = true; chain(p, l, pr.pos, Math.max(dmg, 4f) * 2f, 0); }
            case CORE -> { pr.dead = true; Combat.explode(p, l, pr.pos, 5.0, 28f, true, true); }
            case MAGNET -> pr.dead = true;
            case ROCKET -> { pr.dead = true; Combat.explode(p, l, pr.pos, 6.0, 28f, true, true); }
            default -> { }
        }
    }

    /** Coin ricochet: jumps to the nearest coin or enemy in line of sight. */
    private static void chain(ServerPlayer p, ServerLevel l, Vec3 from, float dmg, int depth) {
        l.sendParticles(ParticleTypes.FLASH, from.x, from.y, from.z, 1, 0, 0, 0, 0);
        Combat.sound(l, from, SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, 1.5f + depth * 0.15f);
        Proj bestCoin = null;
        double cd = 25 * 25;
        for (Proj c : LIST) {
            if (c.dead || c.kind != Kind.COIN || c.level != l) continue;
            double d = c.pos.distanceToSqr(from);
            if (d < cd && los(l, p, from, c.pos)) { cd = d; bestCoin = c; }
        }
        LivingEntity bestE = null;
        double ed = 40 * 40;
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(from, from).inflate(40), x -> x != p && x.isAlive())) {
            Vec3 t = e.position().add(0, e.getBbHeight() * 0.6, 0);
            double d = t.distanceToSqr(from);
            if (d < ed && los(l, p, from, t)) { ed = d; bestE = e; }
        }
        if (bestCoin != null && depth < 4 && (bestE == null || cd <= ed)) {
            Combat.line(l, from, bestCoin.pos, Combat.GOLD, 0.5);
            bestCoin.dead = true;
            chain(p, l, bestCoin.pos, dmg * 1.5f, depth + 1);
        } else if (bestE != null) {
            Vec3 t = bestE.position().add(0, bestE.getBbHeight() * 0.6, 0);
            Combat.line(l, from, t, Combat.GOLD, 0.5);
            Combat.damage(p, bestE, dmg);
            Style.bonus(p, Style.Bonus.COIN);
        }
    }

    private static boolean los(ServerLevel l, ServerPlayer p, Vec3 a, Vec3 b) {
        return l.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    // ---------- arms ----------
    /** Feedbacker parry: turn your own rockets / cores / cannonballs around, punch coins. */
    public static boolean parry(ServerPlayer p, Vec3 eye, Vec3 look, double reach) {
        boolean any = false;
        for (Proj pr : LIST) {
            if (pr.dead || pr.level != p.level()) continue;
            if (pr.kind != Kind.ROCKET && pr.kind != Kind.CANNONBALL && pr.kind != Kind.CORE && pr.kind != Kind.COIN) continue;
            Vec3 to = pr.pos.subtract(eye);
            double d = to.length();
            if (d > reach || d < 0.01 || to.normalize().dot(look) < 0.4) continue;
            any = true;
            if (pr.kind == Kind.COIN) {
                pr.dead = true;
                Combat.trace(p, pr.pos, look, 80, new Combat.Opts(12f, Combat.GOLD).inflate(0.2));
            } else {
                pr.frozen = false;
                pr.vel = look.scale(Math.max(1.6, pr.vel.length() * 1.4));
                pr.noHit = 0;
            }
        }
        return any;
    }

    /** Knuckleblaster shockwave: push rockets / cores / cannonballs away from the player. */
    public static void deflectAway(ServerPlayer p, Vec3 c, double r) {
        for (Proj pr : LIST) {
            if (pr.dead || pr.level != p.level()) continue;
            if (pr.kind != Kind.ROCKET && pr.kind != Kind.CANNONBALL && pr.kind != Kind.CORE) continue;
            Vec3 away = pr.pos.subtract(c);
            if (away.length() > r || away.lengthSqr() < 1.0E-4) continue;
            pr.frozen = false;
            pr.vel = away.normalize().scale(Math.max(1.2, pr.vel.length()));
        }
    }

    // ---------- simulation ----------
    public static void tick() {
        for (int i = 0; i < LIST.size(); i++) {
            Proj pr = LIST.get(i);
            if (pr.dead) continue;
            ServerPlayer o = owner(pr);
            if (o == null) { pr.dead = true; continue; }
            pr.age++;
            if (--pr.ttl <= 0) { expire(pr, o); continue; }
            switch (pr.kind) {
                case NAIL -> nail(pr, o);
                case ROCKET -> rocket(pr, o);
                case CANNONBALL -> cannonball(pr, o);
                case CORE -> core(pr, o);
                case COIN -> coin(pr, o);
                case DRILL -> drill(pr, o);
                case CHAINSAW -> chainsaw(pr, o);
                case MAGNET -> magnet(pr, o);
                case GAS -> gas(pr, o);
            }
        }
        LIST.removeIf(pr -> pr.dead);
    }

    private static ServerPlayer owner(Proj pr) {
        Player pl = pr.level.getPlayerByUUID(pr.owner);
        return pl instanceof ServerPlayer sp && sp.isAlive() ? sp : null;
    }

    private static void expire(Proj pr, ServerPlayer o) {
        switch (pr.kind) {
            case ROCKET -> Combat.explode(o, pr.level, pr.pos, 4.0, 14f, false, true);
            case CORE -> Combat.explode(o, pr.level, pr.pos, 3.5, 14f, false, true);
            case CANNONBALL -> Combat.explode(o, pr.level, pr.pos, 4.0, 14f, false, true);
            default -> { }
        }
        pr.dead = true;
    }

    private static Hit move(Proj pr, ServerPlayer o, double inflate, boolean ignoreEntities) {
        Vec3 end = pr.pos.add(pr.vel);
        BlockHitResult b = pr.level.clip(new ClipContext(pr.pos, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, o));
        boolean blockHit = b.getType() != HitResult.Type.MISS;
        Vec3 segEnd = blockHit ? b.getLocation() : end;
        LivingEntity best = null;
        Vec3 bp = null;
        double bd = Double.MAX_VALUE;
        if (!ignoreEntities) {
            for (LivingEntity e : pr.level.getEntitiesOfClass(LivingEntity.class, new AABB(pr.pos, segEnd).inflate(1.0),
                    x -> x != o && x.isAlive() && !x.isSpectator())) {
                Optional<Vec3> h = e.getBoundingBox().inflate(inflate).clip(pr.pos, segEnd);
                if (h.isPresent()) {
                    double d = pr.pos.distanceToSqr(h.get());
                    if (d < bd) { bd = d; best = e; bp = h.get(); }
                }
            }
        }
        Hit hit = null;
        if (best != null) { hit = new Hit(); hit.e = best; hit.point = bp; }
        else if (blockHit) { hit = new Hit(); hit.b = b; hit.point = segEnd; }
        pr.pos = hit != null ? hit.point : end;
        return hit;
    }

    // ----- nails (+ magnets) -----
    private static void nail(Proj pr, ServerPlayer o) {
        if (pr.magnet == null && !pr.released) {
            Proj m = nearestMagnet(pr);
            if (m != null) { pr.magnet = m; m.count++; pr.vel = Vec3.ZERO; }
        }
        if (pr.magnet != null) {
            if (pr.magnet.dead) { // Nailbomb
                var r = pr.level.random;
                Vec3 v = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian());
                v = v.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : v.normalize();
                pr.vel = v.scale(1.5);
                pr.dmg = Math.min(30f, Math.max(pr.dmg, pr.magnet.count * 0.4f));
                pr.released = true; pr.magnet = null; pr.ttl = 25;
            } else {
                pr.pos = pr.pos.add(pr.magnet.pos.subtract(pr.pos).scale(0.25));
                pr.ttl = Math.max(pr.ttl, 5);
                return;
            }
        }
        pr.vel = pr.vel.add(0, -0.012, 0);
        Hit h = move(pr, o, 0.15, false);
        if (pr.age % 2 == 0) pr.level.sendParticles(ParticleTypes.CRIT, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0, 0, 0, 0);
        if (h != null) {
            if (h.e != null) {
                Combat.damage(o, h.e, pr.dmg);
                if (pr.flaming) h.e.setRemainingFireTicks(80);
            }
            pr.dead = true;
        }
    }

    private static Proj nearestMagnet(Proj nail) {
        Proj best = null;
        double bd = 7 * 7;
        for (Proj m : LIST) {
            if (m.dead || m.kind != Kind.MAGNET || !m.stuck || m.level != nail.level || m.count >= 75) continue;
            double d = m.pos.distanceToSqr(nail.pos);
            if (d < bd) { bd = d; best = m; }
        }
        return best;
    }

    private static void magnet(Proj pr, ServerPlayer o) {
        if (!pr.stuck) {
            Hit h = move(pr, o, 0.2, false);
            if (h != null) { pr.stuck = true; pr.vel = Vec3.ZERO; pr.ttl = 240; if (h.e != null) pr.host = h.e; }
            return;
        }
        if (pr.host != null) {
            if (!pr.host.isAlive()) { pr.dead = true; return; }
            pr.pos = pr.host.position().add(0, pr.host.getBbHeight() * 0.6, 0);
        }
        if (pr.age % 3 == 0) pr.level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pr.pos.x, pr.pos.y, pr.pos.z, 3, 0.25, 0.25, 0.25, 0.1);
        if (pr.ttl < 40 && pr.age % 4 == 0) pr.level.sendParticles(ParticleTypes.FLASH, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0, 0, 0, 0);
    }

    // ----- rockets / cannonball / cores -----
    private static void rocket(Proj pr, ServerPlayer o) {
        if (pr.frozen) {
            if (pr.age % 3 == 0) pr.level.sendParticles(ParticleTypes.END_ROD, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.05, 0.05, 0.05, 0);
            return;
        }
        Hit h = move(pr, o, 0.3, false);
        pr.level.sendParticles(ParticleTypes.FLAME, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.03, 0.03, 0.03, 0.01);
        pr.level.sendParticles(ParticleTypes.SMOKE, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.03, 0.03, 0.03, 0.01);
        if (h != null) {
            pr.dead = true;
            Combat.explode(o, pr.level, pr.pos, 4.0, 14f, false, true);
        }
    }

    private static void cannonball(Proj pr, ServerPlayer o) {
        pr.vel = pr.vel.add(0, -0.03, 0);
        if (pr.noHit > 0) pr.noHit--;
        Hit h = move(pr, o, 0.4, pr.noHit > 0);
        pr.level.sendParticles(ParticleTypes.LARGE_SMOKE, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.05, 0.05, 0.05, 0.01);
        if (h == null) return;
        if (h.e != null) { // bounces off enemies
            Combat.damage(o, h.e, 16f);
            Combat.explode(o, pr.level, pr.pos, 3.0, 10f, false, true);
            if (++pr.bounces >= 3) { pr.dead = true; return; }
            pr.vel = new Vec3(-pr.vel.x * 0.3, 0.6, -pr.vel.z * 0.3);
            pr.noHit = 8;
        } else {
            pr.dead = true;
            Combat.explode(o, pr.level, pr.pos, 4.0, 14f, true, true);
        }
    }

    private static void core(Proj pr, ServerPlayer o) {
        pr.vel = pr.vel.add(0, -0.04, 0);
        Hit h = move(pr, o, 0.3, false);
        pr.level.sendParticles(ParticleTypes.SMALL_FLAME, pr.pos.x, pr.pos.y, pr.pos.z, 2, 0.05, 0.05, 0.05, 0.01);
        if (h != null) {
            pr.dead = true;
            Combat.explode(o, pr.level, pr.pos, 3.5, 14f, false, true);
        }
    }

    private static void coin(Proj pr, ServerPlayer o) {
        pr.vel = pr.vel.add(0, -0.05, 0);
        Hit h = move(pr, o, 0.0, true);
        pr.level.sendParticles(Combat.GOLD, pr.pos.x, pr.pos.y, pr.pos.z, 2, 0.04, 0.04, 0.04, 0);
        if (h != null) pr.dead = true;
    }

    // ----- railcannon drill / chainsaw / gas -----
    private static void drill(Proj pr, ServerPlayer o) {
        if (pr.host == null && !pr.stuck) {
            Hit h = move(pr, o, 0.3, false);
            pr.level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pr.pos.x, pr.pos.y, pr.pos.z, 2, 0.05, 0.05, 0.05, 0.05);
            if (h != null) {
                pr.stuck = true; pr.vel = Vec3.ZERO;
                if (h.e != null) { pr.host = h.e; pr.ttl = 100; } else pr.ttl = 30;
            }
            return;
        }
        if (pr.host != null) {
            if (!pr.host.isAlive()) { pr.dead = true; return; }
            pr.pos = pr.host.position().add(0, pr.host.getBbHeight() * 0.5, 0);
            if (pr.age % 4 == 0) {
                Combat.damage(o, pr.host, 2f);
                o.heal(0.4f); // blood heals V1
                pr.level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pr.pos.x, pr.pos.y, pr.pos.z, 4, 0.2, 0.2, 0.2, 0.1);
            }
        }
    }

    private static void chainsaw(Proj pr, ServerPlayer o) {
        if (!pr.stuck) {
            pr.vel = pr.vel.add(0, -0.02, 0);
            Hit h = move(pr, o, 0.4, false);
            pr.level.sendParticles(ParticleTypes.SMOKE, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.05, 0.05, 0.05, 0.01);
            if (h != null) { pr.stuck = true; pr.vel = Vec3.ZERO; pr.ttl = 120; if (h.e != null) pr.host = h.e; }
            return;
        }
        if (pr.host != null && pr.host.isAlive()) pr.pos = pr.host.position().add(0, pr.host.getBbHeight() * 0.5, 0);
        pr.level.sendParticles(ParticleTypes.CRIT, pr.pos.x, pr.pos.y, pr.pos.z, 2, 0.3, 0.3, 0.3, 0.2);
        if (pr.age % 3 == 0) {
            for (LivingEntity e : pr.level.getEntitiesOfClass(LivingEntity.class, new AABB(pr.pos, pr.pos).inflate(1.6),
                    x -> x != o && x.isAlive())) {
                Combat.damage(o, e, 1.5f);
            }
        }
    }

    private static void gas(Proj pr, ServerPlayer o) {
        pr.vel = pr.vel.add(0, -0.04, 0);
        Hit h = move(pr, o, 0.3, false);
        pr.level.sendParticles(Combat.GAS, pr.pos.x, pr.pos.y, pr.pos.z, 1, 0.03, 0.03, 0.03, 0);
        if (h != null) {
            if (h.e != null) Combat.coat(h.e);
            pr.dead = true;
        }
    }

    private Projectiles() {}
}
