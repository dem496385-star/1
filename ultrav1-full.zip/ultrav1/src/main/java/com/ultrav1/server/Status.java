package com.ultrav1.server;

import com.ultrav1.network.StatusPacket;
import com.ultrav1.network.V1Network;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public final class Status {
    public static void send(ServerPlayer p, String text) {
        V1Network.CHANNEL.send(new StatusPacket(text), PacketDistributor.PLAYER.with(p));
    }

    private Status() {}
}
