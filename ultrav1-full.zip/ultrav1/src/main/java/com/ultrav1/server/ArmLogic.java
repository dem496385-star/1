package com.ultrav1.server;

import com.ultrav1.V1Config;
import com.ultrav1.network.FxPacket;
import com.ultrav1.network.V1Network;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Arms: Feedbacker (blue) and Knuckleblaster (red).
 * Both use "punch exhaustion": max 2, a punch needs >= 1 and costs 1, regenerates over time.
 */
public final class ArmLogic {
    private static final int HOLD_TICKS = 8;        // Knuckleblaster: hold this long for the shockwave
    private static final int SHOCK_COOLDOWN = 40;   // 2 s
    private static final int FEEDBACKER_ANIM = 7;   // ~0.35 s
    private static final int KNUCKLE_ANIM = 24;
    private static final float REGEN = 1f / 16f;    // 1 exhaustion per 0.8 s

    private static final DustParticleOptions BLUE = new DustParticleOptions(new Vector3f(0.25f, 0.65f, 1f), 1.2f);
    private static final DustParticleOptions RED = new DustParticleOptions(new Vector3f(1f, 0.2f, 0.2f), 1.6f);
    private static final DustParticleOptions YELLOW = new DustParticleOptions(new Vector3f(1f, 0.9f, 0.2f), 1.4f);

    private static final class St {
        int arm;                 // 0 = Feedbacker, 1 = Knuckleblaster
        float exh = 2f;
        long ready, shockReady, holdSince, parryUntil;
        boolean held, parried;
    }

    private static final Map<UUID, St> STATE = new HashMap<>();

    private static St st(ServerPlayer p) { return STATE.computeIfAbsent(p.getUUID(), k -> new St()); }

    public static void clear() { STATE.clear(); }

    public static void forget(UUID id) { STATE.remove(id); }

    private static void bar(ServerPlayer p, St s) {
        String name = s.arm == 0 ? "FEEDBACKER" : "KNUCKLEBLASTER";
        int n = (int) s.exh;
        Status.send(p, name + "  " + "|".repeat(n) + ".".repeat(2 - n));
    }

    public static void handle(ServerPlayer p, int action) {
        if (!p.isAlive() || p.isSpectator()) return;
        St s = st(p);
        long now = p.level().getGameTime();
        switch (action) {
            case 2 -> { // swap arm
                s.arm ^= 1;
                s.held = false;
                bar(p, s);
            }
            case 0 -> { // punch pressed
                if (s.arm == 0) punch(p, s, now);
                else { s.held = true; s.holdSince = now; }
            }
            case 1 -> { // punch released
                if (s.arm == 1 && s.held) {
                    s.held = false;
                    if (now - s.holdSince < HOLD_TICKS) punch(p, s, now); // a tap
                }
            }
            case 3, 4, 5 -> WhipLogic.handle(p, action); // Whiplash
            default -> { }
        }
    }

    public static void tick(ServerPlayer p) {
        St s = STATE.get(p.getUUID());
        if (s == null) return;
        long now = p.level().getGameTime();
        if (s.exh < 2f) s.exh = Math.min(2f, s.exh + REGEN);

        if (s.held && now - s.holdSince >= HOLD_TICKS) { // held long enough: shockwave
            s.held = false;
            shockwave(p, s, now);
        }
        if (s.arm == 0 && !s.parried && now <= s.parryUntil) tryParry(p, s); // short parry window after the punch
    }

    // ---------------------------------------------------------------
    private static void punch(ServerPlayer p, St s, long now) {
        if (now < s.ready || s.exh < 1f) return;
        s.exh -= 1f;
        WhipLogic.cancel(p); // using an arm cancels the whiplash
        boolean fb = s.arm == 0;
        s.ready = now + (fb ? FEEDBACKER_ANIM : KNUCKLE_ANIM);
        p.swing(InteractionHand.MAIN_HAND, true);
        ServerLevel l = (ServerLevel) p.level();
        Vec3 look = p.getLookAngle();

        if (fb) {
            s.parryUntil = now + 4;
            s.parried = false;
            if (tryParry(p, s)) { bar(p, s); return; }
        }

        LivingEntity t = Combat.rayEntity(p, 3.2);
        if (t != null) {
            Vec3 at = t.position().add(0, t.getBbHeight() * 0.6, 0);
            Combat.damage(p, t, fb ? 4f : 10f);
            if (fb) {
                t.setDeltaMovement(t.getDeltaMovement().add(look.scale(0.15)));
                l.sendParticles(BLUE, at.x, at.y, at.z, 10, 0.2, 0.2, 0.2, 0.1);
                Combat.sound(l, at, SoundEvents.PLAYER_ATTACK_STRONG, 1.0f, 1.4f);
            } else {
                t.setDeltaMovement(look.scale(1.5).add(0, 0.5, 0)); // sends enemies flying
                l.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0, 0, 0, 0);
                l.sendParticles(RED, at.x, at.y, at.z, 14, 0.3, 0.3, 0.3, 0.15);
                Combat.sound(l, at, SoundEvents.ANVIL_LAND, 1.0f, 0.7f);
                if (!t.isAlive()) { // killing blow: explosion and heal
                    Combat.explode(p, l, at, 3.0, 8f, false, false);
                    p.heal(6f);
                }
            }
            t.hurtMarked = true;
        } else {
            Combat.sound(l, p.getEyePosition(), SoundEvents.PLAYER_ATTACK_SWEEP, 0.6f, fb ? 1.6f : 1.0f);
        }
        bar(p, s);
    }

    /** Feedbacker only. Reflects arrows / fireballs / your own rockets, cores, cannonballs and coins. */
    private static boolean tryParry(ServerPlayer p, St s) {
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        boolean any = false;

        AABB box = new AABB(eye, eye.add(look.scale(3.5))).inflate(2.0);
        for (Projectile pj : l.getEntitiesOfClass(Projectile.class, box,
                e -> e.isAlive() && e.getDeltaMovement().lengthSqr() > 0.01)) {
            Vec3 to = pj.position().subtract(eye);
            double d = to.length();
            if (d > 3.8 || d < 0.01 || to.normalize().dot(look) < 0.4) continue;
            pj.setOwner(p);
            pj.shoot(look.x, look.y, look.z, 2.4f, 0f);
            if (pj instanceof AbstractArrow a) a.setBaseDamage(Math.max(a.getBaseDamage() * 3, 6.0));
            pj.hurtMarked = true;
            any = true;
        }
        if (Projectiles.parry(p, eye, look, 3.8)) any = true;

        if (any) {
            s.parried = true;
            p.heal(V1Config.PARRY_FULL_HEAL.get() ? p.getMaxHealth() : 10f);
            Style.bonus(p, Style.Bonus.PARRY);
            Vec3 at = eye.add(look.scale(1.5));
            l.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0, 0, 0, 0);
            l.sendParticles(YELLOW, at.x, at.y, at.z, 20, 0.4, 0.4, 0.4, 0.15);
            Combat.sound(l, at, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.4f, 2.0f);
            Combat.sound(l, at, SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, 0.8f);
            V1Network.CHANNEL.send(new FxPacket(0.5f, 3f), PacketDistributor.PLAYER.with(p));
        }
        return any;
    }

    /** Knuckleblaster hold: shockwave that knocks enemies back and deflects projectiles. */
    private static void shockwave(ServerPlayer p, St s, long now) {
        if (now < s.shockReady) return;
        s.shockReady = now + SHOCK_COOLDOWN;
        p.swing(InteractionHand.MAIN_HAND, true);
        ServerLevel l = (ServerLevel) p.level();
        Vec3 c = p.position().add(0, 1, 0);
        double r = 5.0;

        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r),
                x -> x != p && x.isAlive())) {
            Vec3 away = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(c);
            if (away.length() > r) continue;
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
            Combat.damage(p, e, 4f);
            e.setDeltaMovement(e.getDeltaMovement().add(away.scale(1.0).add(0, 0.35, 0)));
            e.hurtMarked = true;
        }
        for (Projectile pj : l.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(r), e -> e.isAlive())) {
            Vec3 away = pj.position().subtract(c);
            if (away.length() > r || away.lengthSqr() < 1.0E-4) continue;
            away = away.normalize();
            pj.setOwner(p);
            pj.shoot(away.x, away.y, away.z, 1.8f, 8f); // less accurate than a parry
            pj.hurtMarked = true;
        }
        Projectiles.deflectAway(p, c, r);

        for (int i = 0; i < 36; i++) {
            double a = i * Math.PI * 2 / 36;
            l.sendParticles(RED, c.x + Math.cos(a) * 3, p.getY() + 0.2, c.z + Math.sin(a) * 3, 1, 0, 0.05, 0, 0.02);
        }
        l.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 2, 0.5, 0.2, 0.5, 0);
        Combat.sound(l, c, SoundEvents.ANVIL_LAND, 1.2f, 0.5f);
        V1Network.CHANNEL.send(new FxPacket(0.3f, 5f), PacketDistributor.PLAYER.with(p));
    }

    private ArmLogic() {}
}
