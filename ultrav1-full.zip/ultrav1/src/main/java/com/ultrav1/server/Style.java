package com.ultrav1.server;

import com.ultrav1.V1Config;
import com.ultrav1.network.StylePacket;
import com.ultrav1.network.V1Network;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Style meter: ranks D .. ULTRAKILL. Points come from kills, parries, slams, ricochets...; they drain over time. */
public final class Style {
    public enum Bonus {
        KILL(50, "+KILL"), PARRY(80, "+PARRY"), SLAM(30, "+SLAM"), RICOSHOT(40, "+RICOSHOT"),
        COIN(60, "+COIN"), AIRSHOT(10, "+AIRSHOT"), HEADSHOT(25, "+HEADSHOT");

        public final float points;
        public final String label;

        Bonus(float points, String label) { this.points = points; this.label = label; }
    }

    public static final float[] RANK_AT = {0, 100, 200, 300, 400, 500, 600, 700};
    private static final float MAX = 799f;

    private static final class St {
        float pts;
        int rank;
        long lastGain, lastAir, lastSent;
        float sent = -1;
    }

    private static final Map<UUID, St> STATE = new HashMap<>();

    private static St st(ServerPlayer p) { return STATE.computeIfAbsent(p.getUUID(), k -> new St()); }

    public static int rankOf(float pts) {
        int r = 0;
        for (int i = 0; i < RANK_AT.length; i++) if (pts >= RANK_AT[i]) r = i;
        return r;
    }

    public static void add(ServerPlayer p, float pts) {
        if (!V1Config.STYLE_ENABLED.get()) return;
        St s = st(p);
        s.pts = Math.min(MAX, s.pts + pts);
        s.lastGain = p.level().getGameTime();
    }

    public static void bonus(ServerPlayer p, Bonus b) {
        if (!V1Config.STYLE_ENABLED.get()) return;
        add(p, b.points);
        St s = st(p);
        s.sent = s.pts;
        V1Network.CHANNEL.send(new StylePacket(s.pts, b.ordinal()), PacketDistributor.PLAYER.with(p));
    }

    /** Hitting something while airborne (rate limited). */
    public static void airshot(ServerPlayer p) {
        if (p.onGround() || p.isInWater()) return;
        St s = st(p);
        long now = p.level().getGameTime();
        if (now - s.lastAir < 20) return;
        s.lastAir = now;
        bonus(p, Bonus.AIRSHOT);
    }

    public static void tick(ServerPlayer p) {
        St s = STATE.get(p.getUUID());
        if (s == null) return;
        long now = p.level().getGameTime();

        if (s.pts > 0 && now - s.lastGain > 40) { // starts draining 2 s after the last gain
            float decay = (0.2f + s.rank * 0.12f) * V1Config.STYLE_DECAY.get().floatValue();
            s.pts = Math.max(0f, s.pts - decay);
        }
        int rank = rankOf(s.pts);
        if (rank > s.rank) {
            Combat.sound((net.minecraft.server.level.ServerLevel) p.level(), p.getEyePosition(),
                    SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8f, 0.8f + rank * 0.1f);
            if (rank >= 6) {
                Combat.sound((net.minecraft.server.level.ServerLevel) p.level(), p.getEyePosition(),
                        SoundEvents.LIGHTNING_BOLT_THUNDER, 0.25f, 1.6f);
            }
        }
        s.rank = rank;

        if (now - s.lastSent >= 4 && Math.abs(s.pts - s.sent) > 0.4f) {
            s.lastSent = now;
            s.sent = s.pts;
            V1Network.CHANNEL.send(new StylePacket(s.pts, -1), PacketDistributor.PLAYER.with(p));
        }
    }

    public static void forget(UUID id) { STATE.remove(id); }

    public static void clear() { STATE.clear(); }

    private Style() {}
}
