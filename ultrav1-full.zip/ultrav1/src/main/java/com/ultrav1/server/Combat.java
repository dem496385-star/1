package com.ultrav1.server;

import com.ultrav1.V1Config;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** Hitscan, damage and explosion helpers. 1 ULTRAKILL damage = 4 HP (2 hearts). */
public final class Combat {
    public static final DustParticleOptions BLOOD = new DustParticleOptions(new Vector3f(0.7f, 0f, 0f), 1.3f);
    public static final DustParticleOptions GAS = new DustParticleOptions(new Vector3f(0.35f, 0.25f, 0.05f), 1.2f);
    public static final DustParticleOptions GOLD = new DustParticleOptions(new Vector3f(1f, 0.85f, 0.2f), 1.0f);
    public static final DustParticleOptions ELEC = new DustParticleOptions(new Vector3f(0.9f, 0.95f, 1f), 1.1f);

    // ---------- damage ----------
    public static void damage(ServerPlayer p, LivingEntity e, float hp) {
        if (e == null || !e.isAlive()) return;
        hp *= V1Config.DAMAGE_SCALE.get().floatValue();
        e.invulnerableTime = 0; // rapid-fire weapons must not be eaten by i-frames
        e.hurt(p.damageSources().playerAttack(p), hp);
        if (e != p) {
            Blood.onDealt(p, hp);
            Style.add(p, Math.min(12f, hp * 2f));
            Style.airshot(p);
            if (hp >= 3f) p.playNotifySound(SoundEvents.ARROW_HIT_PLAYER, SoundSource.PLAYERS, 0.4f, 1.5f); // hitmarker
        }
        ((ServerLevel) e.level()).sendParticles(BLOOD, e.getX(), e.getY(0.6), e.getZ(), 4, 0.2, 0.3, 0.2, 0.02);
    }

    public static void coat(LivingEntity e) {
        e.getPersistentData().putLong("v1gas", e.level().getGameTime());
    }

    public static boolean isGassed(LivingEntity e) {
        long t = e.getPersistentData().getLong("v1gas");
        return t > 0 && e.level().getGameTime() - t < 300;
    }

    public static void sound(ServerLevel l, Vec3 v, SoundEvent s, float vol, float pitch) {
        l.playSound(null, v.x, v.y, v.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    // ---------- explosions (no block damage) ----------
    public static void explode(ServerPlayer p, ServerLevel l, Vec3 c, double r, float hp, boolean big, boolean selfPush) {
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r))) {
            Vec3 mid = e.position().add(0, e.getBbHeight() * 0.5, 0);
            double d = mid.distanceTo(c);
            if (d > r) continue;
            float f = (float) (1.0 - 0.5 * d / r);
            Vec3 away = mid.subtract(c);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
            if (e == p) {
                if (selfPush) { // rocket jumps / overpump
                    p.setDeltaMovement(p.getDeltaMovement().add(away.scale(0.9 * f + 0.2)));
                    p.hurtMarked = true;
                    p.hurt(p.damageSources().explosion(null, p), Math.max(1f, hp * 0.12f * f) * V1Config.SELF_EXPLOSION_SCALE.get().floatValue());
                }
                continue;
            }
            float dmg = hp * f;
            if (isGassed(e)) {
                dmg *= 2f;
                e.setRemainingFireTicks(120);
            }
            damage(p, e, dmg);
            e.setDeltaMovement(e.getDeltaMovement().add(away.scale(0.5 * f).add(0, 0.25, 0)));
            e.hurtMarked = true;
        }
        l.sendParticles(big ? ParticleTypes.EXPLOSION_EMITTER : ParticleTypes.EXPLOSION, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        l.sendParticles(ParticleTypes.FLAME, c.x, c.y, c.z, 25, r * 0.3, r * 0.3, r * 0.3, 0.06);
        sound(l, c, SoundEvents.FIREWORK_ROCKET_BLAST, 2.0f, big ? 0.5f : 0.7f);
        sound(l, c, SoundEvents.ANVIL_LAND, 0.8f, 0.5f);
    }

    // ---------- hitscan ----------
    public static final class Opts {
        public float dmg;
        public int pierce = 1, ricochet = 0;
        public float head = 1f;
        public DustParticleOptions dust;
        public double inflate = 0.1, step = 0.6;

        public Opts(float dmg, DustParticleOptions dust) { this.dmg = dmg; this.dust = dust; }
        public Opts pierce(int n) { pierce = n; return this; }
        public Opts ricochet(int n) { ricochet = n; return this; }
        public Opts head(float m) { head = m; return this; }
        public Opts inflate(double v) { inflate = v; return this; }
        public Opts step(double v) { step = v; return this; }
    }

    public static final class Result {
        public Vec3 end;
        public LivingEntity first;
    }

    private static final class Hit {
        final LivingEntity e; final Vec3 pos; final double dist2;
        Hit(LivingEntity e, Vec3 pos, double dist2) { this.e = e; this.pos = pos; this.dist2 = dist2; }
    }

    public static Result trace(ServerPlayer p, Vec3 start, Vec3 dir, double range, Opts o) {
        ServerLevel l = (ServerLevel) p.level();
        Result res = new Result();
        res.end = start;
        Vec3 s = start, d = dir.normalize();
        double left = range;
        int pierced = 0, ric = o.ricochet;
        boolean ricocheted = false;

        for (int seg = 0; seg < 6 && left > 0.1; seg++) {
            Vec3 far = s.add(d.scale(left));
            BlockHitResult bhr = l.clip(new ClipContext(s, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            boolean blockHit = bhr.getType() != HitResult.Type.MISS;
            Vec3 segEnd = blockHit ? bhr.getLocation() : far;

            // coins, cores, magnets and frozen rockets can be shot
            Projectiles.Proj pr = Projectiles.firstHit(l, s, segEnd);
            if (pr != null) {
                line(l, s, pr.pos, o.dust, o.step);
                res.end = pr.pos;
                Projectiles.onShot(p, pr, o.dmg);
                return res;
            }

            List<Hit> hits = new ArrayList<>();
            for (LivingEntity le : l.getEntitiesOfClass(LivingEntity.class, new AABB(s, segEnd).inflate(2.0),
                    x -> x != p && x.isAlive() && !x.isSpectator())) {
                Optional<Vec3> hp = le.getBoundingBox().inflate(o.inflate).clip(s, segEnd);
                if (hp.isPresent()) hits.add(new Hit(le, hp.get(), s.distanceToSqr(hp.get())));
            }
            hits.sort(Comparator.comparingDouble(h -> h.dist2));

            if (ricocheted && !hits.isEmpty()) Style.bonus(p, Style.Bonus.RICOSHOT);
            Vec3 cut = null;
            for (Hit h : hits) {
                float dmg = o.dmg;
                if (o.head > 1f && h.pos.y > h.e.getY() + h.e.getBbHeight() * 0.8) {
                    dmg *= o.head;
                    Style.bonus(p, Style.Bonus.HEADSHOT);
                }
                damage(p, h.e, dmg);
                if (res.first == null) res.first = h.e;
                if (++pierced >= o.pierce) { cut = h.pos; break; }
            }
            if (cut != null) {
                line(l, s, cut, o.dust, o.step);
                res.end = cut;
                return res;
            }

            line(l, s, segEnd, o.dust, o.step);
            res.end = segEnd;
            if (blockHit && ric > 0) {
                Direction face = bhr.getDirection();
                Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
                d = d.subtract(n.scale(2 * d.dot(n))).normalize();
                left -= s.distanceTo(segEnd);
                s = segEnd.add(n.scale(0.02));
                ric--;
                ricocheted = true;
                l.sendParticles(ParticleTypes.ELECTRIC_SPARK, s.x, s.y, s.z, 8, 0.1, 0.1, 0.1, 0.2);
                continue;
            }
            return res;
        }
        return res;
    }

    public static void line(ServerLevel l, Vec3 a, Vec3 b, DustParticleOptions dust, double step) {
        double len = a.distanceTo(b);
        if (len < 0.5) return;
        Vec3 st = b.subtract(a).normalize().scale(step);
        int n = (int) Math.min(160, len / step);
        Vec3 pt = a;
        for (int i = 0; i < n; i++) {
            pt = pt.add(st);
            l.sendParticles(dust, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
    }

    /** First living entity along the player's look direction (blocked by walls). */
    public static LivingEntity rayEntity(ServerPlayer p, double range) {
        ServerLevel l = (ServerLevel) p.level();
        Vec3 s = p.getEyePosition();
        Vec3 e = s.add(p.getLookAngle().scale(range));
        BlockHitResult b = l.clip(new ClipContext(s, e, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (b.getType() != HitResult.Type.MISS) e = b.getLocation();
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity le : l.getEntitiesOfClass(LivingEntity.class, new AABB(s, e).inflate(1.5), x -> x != p && x.isAlive())) {
            Optional<Vec3> h = le.getBoundingBox().inflate(0.2).clip(s, e);
            if (h.isPresent()) {
                double dd = s.distanceToSqr(h.get());
                if (dd < bd) { bd = dd; best = le; }
            }
        }
        return best;
    }

    private Combat() {}
}
