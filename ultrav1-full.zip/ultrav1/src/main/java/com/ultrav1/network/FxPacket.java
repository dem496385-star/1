package com.ultrav1.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: screen flash and camera shake (parry, shockwave). */
public class FxPacket {
    public final float flash, shake;

    public FxPacket(float flash, float shake) {
        this.flash = flash;
        this.shake = shake;
    }

    public static void encode(FxPacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.flash);
        buf.writeFloat(m.shake);
    }

    public static FxPacket decode(FriendlyByteBuf buf) { return new FxPacket(buf.readFloat(), buf.readFloat()); }

    public static void handle(FxPacket m, CustomPayloadEvent.Context ctx) {
        // only ever runs on the client, so the client class is resolved lazily
        com.ultrav1.client.V1Effects.fx(m.flash, m.shake);
        ctx.setPacketHandled(true);
    }
}
