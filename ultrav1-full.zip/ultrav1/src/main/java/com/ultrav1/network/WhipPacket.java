package com.ultrav1.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: start reeling towards a point (reel = true) or stop (reel = false). */
public class WhipPacket {
    public final boolean reel;
    public final float x, y, z;

    public WhipPacket(boolean reel, float x, float y, float z) {
        this.reel = reel;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public static void encode(WhipPacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.reel);
        buf.writeFloat(m.x);
        buf.writeFloat(m.y);
        buf.writeFloat(m.z);
    }

    public static WhipPacket decode(FriendlyByteBuf buf) {
        return new WhipPacket(buf.readBoolean(), buf.readFloat(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(WhipPacket m, CustomPayloadEvent.Context ctx) {
        com.ultrav1.client.V1WhipClient.onPacket(m.reel, m.x, m.y, m.z);
        ctx.setPacketHandled(true);
    }
}
