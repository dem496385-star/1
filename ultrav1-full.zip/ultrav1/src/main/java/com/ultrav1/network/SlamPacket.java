package com.ultrav1.network;

import com.ultrav1.server.V1ServerEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Client -> server. impact=false: slam started. impact=true: slam hit the ground. */
public class SlamPacket {
    public final boolean impact;
    public final float fallDistance;

    public SlamPacket(boolean impact, float fallDistance) {
        this.impact = impact;
        this.fallDistance = fallDistance;
    }

    public static void encode(SlamPacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.impact);
        buf.writeFloat(m.fallDistance);
    }

    public static SlamPacket decode(FriendlyByteBuf buf) {
        return new SlamPacket(buf.readBoolean(), buf.readFloat());
    }

    public static void handle(SlamPacket m, CustomPayloadEvent.Context ctx) {
        ServerPlayer p = ctx.getSender();
        if (p == null) return;
        if (!m.impact) V1ServerEvents.startSlam(p);
        else V1ServerEvents.slamImpact(p, m.fallDistance);
        ctx.setPacketHandled(true);
    }
}
