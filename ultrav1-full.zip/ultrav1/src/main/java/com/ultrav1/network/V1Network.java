package com.ultrav1.network;

import com.ultrav1.UltraV1;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.SimpleChannel;

public final class V1Network {
    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(UltraV1.MODID, "main"))
            .networkProtocolVersion(1)
            .simpleChannel();

    public static void init() {
        CHANNEL.messageBuilder(SlamPacket.class, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SlamPacket::encode)
                .decoder(SlamPacket::decode)
                .consumerMainThread(SlamPacket::handle)
                .add();
        CHANNEL.messageBuilder(FirePacket.class, NetworkDirection.PLAY_TO_SERVER)
                .encoder(FirePacket::encode)
                .decoder(FirePacket::decode)
                .consumerMainThread(FirePacket::handle)
                .add();
        CHANNEL.messageBuilder(ArmPacket.class, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ArmPacket::encode)
                .decoder(ArmPacket::decode)
                .consumerMainThread(ArmPacket::handle)
                .add();
        CHANNEL.messageBuilder(FxPacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(FxPacket::encode)
                .decoder(FxPacket::decode)
                .consumerMainThread(FxPacket::handle)
                .add();
        CHANNEL.messageBuilder(WhipPacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(WhipPacket::encode)
                .decoder(WhipPacket::decode)
                .consumerMainThread(WhipPacket::handle)
                .add();
        CHANNEL.messageBuilder(StylePacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(StylePacket::encode)
                .decoder(StylePacket::decode)
                .consumerMainThread(StylePacket::handle)
                .add();
        CHANNEL.messageBuilder(StatusPacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(StatusPacket::encode)
                .decoder(StatusPacket::decode)
                .consumerMainThread(StatusPacket::handle)
                .add();
    }

    private V1Network() {}
}
