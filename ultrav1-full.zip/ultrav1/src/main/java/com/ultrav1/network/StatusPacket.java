package com.ultrav1.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: short status text for the HUD line (pump count, spin, heatsinks, arm...). */
public class StatusPacket {
    public final String text;

    public StatusPacket(String text) { this.text = text; }

    public static void encode(StatusPacket m, FriendlyByteBuf buf) { buf.writeUtf(m.text, 64); }

    public static StatusPacket decode(FriendlyByteBuf buf) { return new StatusPacket(buf.readUtf(64)); }

    public static void handle(StatusPacket m, CustomPayloadEvent.Context ctx) {
        com.ultrav1.client.V1Hud.onStatus(m.text);
        ctx.setPacketHandled(true);
    }
}
