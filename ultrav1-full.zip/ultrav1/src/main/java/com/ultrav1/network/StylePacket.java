package com.ultrav1.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: current style points and an optional bonus label (bonus = -1 for none). */
public class StylePacket {
    public final float points;
    public final int bonus;

    public StylePacket(float points, int bonus) {
        this.points = points;
        this.bonus = bonus;
    }

    public static void encode(StylePacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.points);
        buf.writeByte(m.bonus);
    }

    public static StylePacket decode(FriendlyByteBuf buf) { return new StylePacket(buf.readFloat(), buf.readByte()); }

    public static void handle(StylePacket m, CustomPayloadEvent.Context ctx) {
        com.ultrav1.client.V1StyleHud.onPacket(m.points, m.bonus);
        ctx.setPacketHandled(true);
    }
}
