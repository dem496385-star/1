package com.ultrav1.network;

import com.ultrav1.server.ArmLogic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Client -> server. action: 0 = punch key pressed, 1 = punch key released, 2 = swap arm. */
public class ArmPacket {
    public final int action;

    public ArmPacket(int action) { this.action = action; }

    public static void encode(ArmPacket m, FriendlyByteBuf buf) { buf.writeByte(m.action); }

    public static ArmPacket decode(FriendlyByteBuf buf) { return new ArmPacket(buf.readByte()); }

    public static void handle(ArmPacket m, CustomPayloadEvent.Context ctx) {
        ServerPlayer p = ctx.getSender();
        if (p != null) ArmLogic.handle(p, m.action);
        ctx.setPacketHandled(true);
    }
}
