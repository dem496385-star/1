package com.ultrav1.network;

import com.ultrav1.server.WeaponLogic;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Client -> server: fire button state. alt = right mouse; press = button went down this tick. */
public class FirePacket {
    public final boolean alt, press;

    public FirePacket(boolean alt, boolean press) {
        this.alt = alt;
        this.press = press;
    }

    public static void encode(FirePacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.alt);
        buf.writeBoolean(m.press);
    }

    public static FirePacket decode(FriendlyByteBuf buf) {
        return new FirePacket(buf.readBoolean(), buf.readBoolean());
    }

    public static void handle(FirePacket m, CustomPayloadEvent.Context ctx) {
        ServerPlayer p = ctx.getSender();
        if (p != null) WeaponLogic.fire(p, m.alt, m.press);
        ctx.setPacketHandled(true);
    }
}
