package com.ultrav1;

import com.ultrav1.network.V1Network;
import com.ultrav1.server.V1ServerEvents;
import com.ultrav1.weapon.ModItems;
import com.ultrav1.weapon.Weapon;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(UltraV1.MODID)
public class UltraV1 {
    public static final String MODID = "ultrav1";

    public UltraV1() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, V1Config.SPEC);
        V1Network.init();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        bus.addListener(UltraV1::tabs);
        MinecraftForge.EVENT_BUS.register(new V1ServerEvents());
    }

    private static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) {
            for (Weapon w : Weapon.values()) e.accept(ModItems.get(w));
        }
    }
}
