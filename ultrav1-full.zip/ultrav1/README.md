# ULTRAKILL: V1 (Forge 1.21.1) — Stage 1: movement

Build: copy gradlew / gradle/wrapper from the official Forge 1.21.1 MDK into this folder, then
  ./gradlew runClient     # test
  ./gradlew build         # jar in build/libs

Controls (rebind in Controls -> ULTRAKILL V1):
  Left Shift dash (3 charges, ~2.5 s per charge)
  Space      wall jump (in the air next to a wall, up to 3 times until you land)
  Left Ctrl  slide on the ground / slam in the air

Slam storage:
  1. In the air press Left Ctrl (slam) and, while falling, jump off a wall (Space) -> "SLAM STORED" appears.
  2. After you land you have ~0.4 s:  Ctrl = launch forward,  Space = launch high,  Ctrl + Space = arc.
  Strength depends on how far you fell. Numbers are constants at the top of V1Movement.java.

TLauncher: install Forge 1.21.1 (Java 21), put build/libs/ultrav1-0.4.2.jar into .minecraft/mods.

Effects (V1Effects.java): FOV kick on dash/slam/slide/speed, camera shake, screen flash on slam/launch,
blue dash trail, flame slam trail, slide sparks, wall-jump dust, orange shockwave rings + blood on slam hits,
fire swirl while slam is stored. All vanilla particles/sounds - swap in custom sounds via sounds.json later.

Build the jar on GitHub (no local setup needed):
  1. Create a GitHub repo and upload this whole folder (keep the .github folder).
  2. Open the Actions tab -> "Build mod jar" runs on every push (or press "Run workflow").
  3. When it is green, open the run -> Artifacts -> ultrav1-jar -> download -> put the jar into .minecraft/mods.
  Optional: push a tag (git tag v0.1.0 && git push --tags) and the jar is attached to a GitHub Release.

==================== STAGE 2: WEAPONS ====================
All 15 variants (5 weapons x blue/green/red). You get them on first join; /v1give gives them again
(also in the Creative "Combat" tab). LMB = primary fire, RMB = alternate fire. 1 ULTRAKILL damage = 4 HP.

REVOLVER   Piercer (blue): alt = charged piercing shot (5 s)   Marksman (green): alt = coin, shoot it to ricochet
           Sharpshooter (red): ricocheting piercing shots, alt = spin (more ricochets)
SHOTGUN    Core Eject (blue): alt = explosive core (shoot it for a bigger blast)
           Pump Charge (green): alt = pump (more pellets, 3 pumps = overpump explosion)
           Sawed-On (red): alt = launch a chainsaw
NAILGUN    Attractor (blue): alt = magnets (pull nails, break one = nailbomb; slam breaks them too)
           Overheat (green): alt = heatsink burst of flaming nails (needs heat from firing)
           JumpStart (red): alt = cable, 5 s later a big shock
RAILCANNON Electric (blue): piercing beam   Screwdriver (green): drill that lodges in an enemy, heals you
           Malicious (red): beam with a huge explosion.  16 s shared cooldown, RMB = zoom
ROCKET     Freezeframe (blue): alt = freeze / release rockets (shoot a frozen rocket = big blast)
           S.R.S. Cannon (green): alt = bouncing cannonball   Firestarter (red): alt (hold) = gasoline, burns hotter
Rocket / explosion jumps push you (and hurt a little). Overpump also pushes you.

==================== STAGE 3 (part 1): ARMS ====================
Works with any item in hand. V = punch, G = swap arm (rebind in Controls). Punch exhaustion: max 2, a punch costs 1.
FEEDBACKER (blue): fast punch (1 dmg). Punch at the right moment (~0.2 s window) to PARRY: reflects arrows,
  fireballs and your own rockets / cores / cannonballs, punches coins into a ricochet, and heals you to full.
KNUCKLEBLASTER (red): slow heavy punch (2.5 dmg), launches enemies, kills explode and heal a bit, cannot parry.
  HOLD the punch key (~0.4 s) = shockwave: knocks enemies back and deflects projectiles (2 s cooldown).

==================== STAGE 3 (part 2): WHIPLASH + BLOOD ====================
WHIPLASH (green arm), key R: HOLD to throw the hook (40 blocks), RELEASE to pull.
  Light enemies are pulled to you; heavy enemies (big / lots of HP) and surfaces pull YOU.
  Jump while reeling = cancel with a small hop (lose momentum). Press R again or punch = cancel. 0.5 s cooldown.
BLOOD HEAL: ~60% of the damage you take becomes "hard damage". Hurting enemies heals you back, but only up to that
  amount (tune in Blood.java). Parry heals fully.


==================== STAGE 4: STYLE, BALANCE ====================
STYLE METER (top right): ranks D, C, B, A, S, SS, SSS, ULTRAKILL. Points come from kills, damage, parries, slams,
  ricochets, coin chains, headshots and airshots. They start draining 2 s after your last gain, faster at higher ranks.
  Rank-ups play a sound (SSS+ adds thunder). A hitmarker sound plays on solid hits.
BALANCE: edit config/ultrav1-common.toml after the first launch (damage multiplier, self rocket damage,
  parry heal, railcannon / rocket cooldowns, blood healing, style on/off and drain speed).
SOUNDS: everything uses vanilla sounds. To add your own, put .ogg files in assets/ultrav1/sounds/ and
  register them in assets/ultrav1/sounds.json.


NOTE (HUD): Forge 1.21.1 has no HUD render event, so the HUD is one text line above the hotbar:
  DASH [###]  <style rank + bar + latest bonus>  <status: pump count, spin, heatsinks, arm...>
The white screen flash on parry / slam was dropped for the same reason (camera shake and FOV kicks stay).


CHANGES 0.4.2: you start with only the blue revolver (Piercer); /v1give or the Creative "Combat" tab give the rest.
Slam is half as fast; slam storage launches are twice as strong; the slam only starts on a fresh Ctrl press in the air
(holding Ctrl while falling just falls). Weapon textures are mirrored.
